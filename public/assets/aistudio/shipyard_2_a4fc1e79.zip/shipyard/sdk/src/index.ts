export type AppStatus = "DRAFT" | "QUEUED" | "CLARIFYING" | "GENERATING" | "DEPLOYING" | "LIVE" | "FAILED";

export interface AppWallet { id: string; address: string; balanceWei: string }
export interface Token { id: string; symbol: string; name: string; contract: string | null; creatorShareBps: number; feesAccruedWei: string; feesClaimedWei: string }
export interface PlatformIntegration { kind: "WEB" | "FARCASTER" | "TELEGRAM" | "WORLD" | "CELO" | "BASE"; enabled: boolean }

export interface App {
  id: string;
  name: string;
  slug: string;
  idea: string;
  status: AppStatus;
  isPublic: boolean;
  liveUrl: string | null;
  repoUrl: string | null;
  logoUrl: string | null;
  opens: number;
  uniqueUsers: number;
  revenueCents: number;
  createdAt: string;
  updatedAt: string;
  wallet?: AppWallet | null;
  token?: Token | null;
  platforms?: PlatformIntegration[];
}

export interface ChatMessage { id: string; role: "USER" | "ASSISTANT"; content: string; createdAt: string }
export interface CreditTransaction { id: string; type: "PURCHASE" | "SPEND" | "GRANT" | "ADJUSTMENT"; amount: number; reason: string; createdAt: string }
export interface AgentReply { reply: string; buildId: string; paused: boolean }

export class ShipyardError extends Error {
  constructor(message: string, public status: number, public body?: unknown) {
    super(message);
  }
}

export interface ShipyardOptions {
  /** e.g. https://app.example.com */
  baseUrl: string;
  /** Server-to-server API key (`sk_live_…`), sent as a Bearer token. Preferred for automation. */
  apiKey?: string;
  /** Value of the `sy_session` cookie, for server-side use. Browsers send it automatically. */
  sessionToken?: string;
  fetch?: typeof fetch;
}

export class Shipyard {
  private f: typeof fetch;
  constructor(private opts: ShipyardOptions) {
    this.f = opts.fetch ?? fetch;
  }

  private async req<T>(path: string, init: RequestInit = {}): Promise<T> {
    const headers = new Headers(init.headers);
    if (init.body) headers.set("Content-Type", "application/json");
    if (this.opts.apiKey) headers.set("Authorization", `Bearer ${this.opts.apiKey}`);
    else if (this.opts.sessionToken) headers.set("Cookie", `sy_session=${this.opts.sessionToken}`);
    const res = await this.f(new URL(path, this.opts.baseUrl), { ...init, headers, credentials: "include" });
    const body = await res.json().catch(() => ({}));
    if (!res.ok) throw new ShipyardError((body as { error?: string }).error ?? res.statusText, res.status, body);
    return body as T;
  }

  apps = {
    list: () => this.req<{ apps: App[] }>("/api/apps"),
    get: (id: string) => this.req<{ app: App; permissions: { iterate?: boolean; claim?: boolean } }>(`/api/apps/${id}`),
    create: (input: { name: string; idea: string; orgId?: string }) =>
      this.req<{ app: App }>("/api/apps", { method: "POST", body: JSON.stringify(input) }),
  };

  agent = {
    send: (appId: string, message: string) =>
      this.req<AgentReply>("/api/agent", { method: "POST", body: JSON.stringify({ appId, message }) }),
    state: (appId: string) =>
      this.req<{ messages: ChatMessage[]; status: AppStatus; step: string | null }>(`/api/agent?appId=${encodeURIComponent(appId)}`),
    /** Poll until the build reaches LIVE or FAILED. */
    waitUntilDone: async (appId: string, intervalMs = 2500, timeoutMs = 10 * 60_000) => {
      const start = Date.now();
      for (;;) {
        const s = await this.agent.state(appId);
        if (s.status === "LIVE" || s.status === "FAILED") return s;
        if (Date.now() - start > timeoutMs) throw new ShipyardError("Timed out waiting for build", 408);
        await new Promise((r) => setTimeout(r, intervalMs));
      }
    },
  };

  credits = {
    get: () => this.req<{ balance: number; transactions: CreditTransaction[] }>("/api/credits"),
    topUp: (pack: "100" | "500" | "2000") =>
      this.req<{ granted?: number; checkoutUrl?: string }>("/api/credits", { method: "POST", body: JSON.stringify({ pack }) }),
  };

  wallet = {
    withdraw: (input: { appId: string; toAddress: string; amountWei: string }) =>
      this.req<{ withdrawal: { id: string; amountWei: string; toAddress: string } }>("/api/wallet/withdraw", { method: "POST", body: JSON.stringify(input) }),
  };

  tokens = {
    claimFees: (appId: string) =>
      this.req<{ claim: { id: string; amountWei: string } }>("/api/tokens/claim", { method: "POST", body: JSON.stringify({ appId }) }),
  };

  orgs = {
    list: () => this.req<{ orgs: Org[] }>("/api/orgs"),
    create: (input: { name: string; slug: string }) => this.req<{ org: Org }>("/api/orgs", { method: "POST", body: JSON.stringify(input) }),
    members: (orgId: string) => this.req<{ members: Member[] }>(`/api/orgs/${orgId}/members`),
    setRole: (orgId: string, userId: string, role: OrgRole) =>
      this.req<{ member: { userId: string; role: OrgRole } }>(`/api/orgs/${orgId}/members/${userId}`, { method: "PATCH", body: JSON.stringify({ role }) }),
    removeMember: (orgId: string, userId: string) => this.req<{ ok: true }>(`/api/orgs/${orgId}/members/${userId}`, { method: "DELETE" }),
    invite: (orgId: string, input: { email: string; role?: OrgRole }) =>
      this.req<{ emailed: boolean; inviteUrl?: string }>(`/api/orgs/${orgId}/invitations`, { method: "POST", body: JSON.stringify(input) }),
    auditLog: (orgId: string, q: { from?: string; to?: string; limit?: number } = {}) => {
      const sp = new URLSearchParams(Object.entries(q).filter(([, v]) => v !== undefined).map(([k, v]) => [k, String(v)]));
      return this.req<{ logs: Array<{ id: string; createdAt: string; action: string; target: string | null; meta: unknown }> }>(`/api/orgs/${orgId}/audit?${sp}`);
    },
  };

  webhooks = {
    list: (orgId: string) => this.req<{ endpoints: WebhookEndpoint[] }>(`/api/orgs/${orgId}/webhooks`),
    /** The signing secret is returned once, at creation. */
    create: (orgId: string, input: { url: string; events: WebhookEvent[] }) =>
      this.req<{ id: string; secret: string }>(`/api/orgs/${orgId}/webhooks`, { method: "POST", body: JSON.stringify(input) }),
    delete: (orgId: string, hookId: string) => this.req<{ ok: true }>(`/api/orgs/${orgId}/webhooks/${hookId}`, { method: "DELETE" }),
  };

  platforms = {
    set: (appId: string, input: { kind: "WEB" | "BASE" | "CELO" | "FARCASTER" | "WORLD" | "TELEGRAM"; enabled: boolean; worldAppId?: string; botToken?: string }) =>
      this.req<{ platform: { kind: string; enabled: boolean } }>(`/api/apps/${appId}/platforms`, { method: "PATCH", body: JSON.stringify(input) }),
  };

  apiKeys = {
    list: () => this.req<{ keys: Array<{ id: string; name: string; prefix: string; readOnly: boolean; lastUsedAt: string | null }> }>("/api/api-keys"),
    /** Must be called from a signed-in session, not with another API key. The key is returned once. */
    create: (input: { name: string; readOnly?: boolean; expiresInDays?: number }) =>
      this.req<{ id: string; key: string; prefix: string }>("/api/api-keys", { method: "POST", body: JSON.stringify(input) }),
    revoke: (id: string) => this.req<{ ok: true }>(`/api/api-keys/${id}`, { method: "DELETE" }),
  };
}

export type OrgRole = "OWNER" | "ADMIN" | "BUILDER" | "VIEWER";
export type WebhookEvent = "*" | "app.live" | "app.failed" | "wallet.withdrawal" | "fees.claimed" | "member.added" | "member.removed";
export interface Org { id: string; name: string; slug: string; role: OrgRole }
export interface Member { userId: string; role: OrgRole; handle: string | null; email: string | null }
export interface WebhookEndpoint { id: string; url: string; events: WebhookEvent[]; enabled: boolean }

/** Verify a delivery from Shipyard. Works in Node 18+, Deno, Bun and browsers (WebCrypto). */
export async function verifyWebhook(secret: string, rawBody: string, signatureHeader: string, toleranceSec = 300): Promise<boolean> {
  const parts = Object.fromEntries(signatureHeader.split(",").map((p) => p.split("=") as [string, string]));
  const t = Number(parts.t);
  if (!t || !parts.v1 || Math.abs(Date.now() / 1000 - t) > toleranceSec) return false;
  const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  const mac = await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(`${t}.${rawBody}`));
  const hex = [...new Uint8Array(mac)].map((b) => b.toString(16).padStart(2, "0")).join("");
  if (hex.length !== parts.v1.length) return false;
  let diff = 0;
  for (let i = 0; i < hex.length; i++) diff |= hex.charCodeAt(i) ^ parts.v1.charCodeAt(i); // constant-time compare
  return diff === 0;
}

export function createClient(opts: ShipyardOptions): Shipyard {
  return new Shipyard(opts);
}
