# @shipyard/sdk

Typed client for the Shipyard HTTP API (apps, build agents, credits, wallets, orgs, webhooks, API keys).

```ts
import { createClient, verifyWebhook } from "@shipyard/sdk";

// Server-to-server: create a key in the Team page (or sy.apiKeys.create from a signed-in session)
const sy = createClient({ baseUrl: "https://your-shipyard.app", apiKey: process.env.SHIPYARD_API_KEY });

const { app } = await sy.apps.create({ name: "Pixel Arcade", idea: "Retro arcade with onchain high scores and weekly prizes." });
const first = await sy.agent.send(app.id, "Surprise me");        // paused: true => the planner asked questions
if (first.paused) await sy.agent.send(app.id, "Casual gamers; web + Farcaster; no token.");
console.log((await sy.agent.waitUntilDone(app.id)).status);       // LIVE | FAILED
```

## Webhooks

```ts
const hook = await sy.webhooks.create(orgId, { url: "https://example.com/hooks/shipyard", events: ["app.live", "app.failed"] });
// store hook.secret — it is shown once

// in your handler (use the RAW body string):
const ok = await verifyWebhook(secret, rawBody, req.headers["x-shipyard-signature"]);
```

Deliveries are retried with backoff (1m, 5m, 30m, 2h, 12h). Respond 2xx quickly; dedupe on `X-Shipyard-Delivery`.

## Errors

`ShipyardError` carries `status`: 401 unauthenticated, 402 insufficient credits, 403 forbidden (including read-only keys writing), 409 conflict, 422 generated code failed review, 429 rate limited.

Build: `npm install && npm run build`.
