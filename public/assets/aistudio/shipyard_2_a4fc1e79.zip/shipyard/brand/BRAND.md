# Shipyard brand guide

**Name:** Shipyard · **Tagline:** Describe it. Ship it.

## Logo
- `logo.svg` (light backgrounds), `logo-dark.svg` (dark backgrounds), `logo-mark.svg` (app icon / favicon).
- Keep clear space equal to the mark's corner radius. Minimum mark size 24px.

## Color
| Token | Hex | Use |
|---|---|---|
| brand-50 | #ecfdf5 | page tint, chips |
| brand-400 | #34d399 | accents on dark |
| brand-500 | #10b981 | focus rings, borders |
| brand-600 | #059669 | primary buttons, links |
| brand-700 | #047857 | hover |
| ink-900 | #064e3b | wordmark on light |
| night-950 | #022c22 | dark backgrounds |

## Type
Inter (fallback system-ui). Headings 700–800, body 400–500.

## Shape and motion
Cards radius 16px, buttons 12px, soft shadows, translucent surfaces with blur. Motion short and eased (150–250ms).
