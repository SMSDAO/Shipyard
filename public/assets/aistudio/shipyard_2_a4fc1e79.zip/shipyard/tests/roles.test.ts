import { describe, expect, it } from "vitest";
import { DEFAULT_PLAN, ROLES, stepsFor } from "@/lib/agent/roles";

describe("agent roles", () => {
  it("every pipeline step uses a tool its role is allowed to run", () => {
    for (const plan of [DEFAULT_PLAN, { needsContracts: false, launchToken: true, tokenSymbol: "ARC" }]) {
      for (const role of ["designer", "coder", "reviewer", "deployer"] as const) {
        for (const s of stepsFor(role, plan)) expect(ROLES[role].tools).toContain(s.tool);
      }
    }
  });

  it("plan toggles contracts and token launch", () => {
    const tools = (r: "coder" | "deployer", p: Parameters<typeof stepsFor>[1]) => stepsFor(r, p).map((s) => s.tool);
    expect(tools("coder", { needsContracts: false, launchToken: false })).toEqual(["generate_nextjs_code"]);
    expect(tools("coder", DEFAULT_PLAN)).toContain("generate_smart_contracts");
    expect(tools("deployer", DEFAULT_PLAN)).not.toContain("launch_token");
    expect(tools("deployer", { needsContracts: true, launchToken: true })).toContain("launch_token");
  });

  it("deployer always ends by marking the app live, after the wallet exists", () => {
    const t = stepsFor("deployer", DEFAULT_PLAN).map((s) => s.tool);
    expect(t.at(-1)).toBe("update_app_status");
    expect(t.indexOf("create_app_wallet")).toBeLessThan(t.indexOf("update_app_status"));
  });

  it("tools are not shared across roles", () => {
    const all = Object.values(ROLES).flatMap((r) => r.tools);
    expect(new Set(all).size).toBe(all.length);
  });
});
