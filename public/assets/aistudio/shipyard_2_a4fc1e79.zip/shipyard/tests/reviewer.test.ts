import { describe, expect, it } from "vitest";
import { isSafePath, reviewFiles } from "@/lib/agent/reviewer";

const good = {
  "package.json": JSON.stringify({ name: "x", dependencies: { next: "^15.0.0" } }),
  "app/page.tsx": "export default function P(){return null}",
};

describe("reviewFiles", () => {
  it("passes a minimal valid app", () => {
    expect(reviewFiles(good)).toEqual({ ok: true, issues: [] });
  });

  it("fails on missing package.json / entry point / empty output", () => {
    expect(reviewFiles({}).ok).toBe(false);
    expect(reviewFiles({ "app/page.tsx": "x" }).issues.some((i) => i.file === "package.json")).toBe(true);
    expect(reviewFiles({ "package.json": good["package.json"] }).issues.some((i) => /entry point/.test(i.message))).toBe(true);
  });

  it("rejects invalid or next-less package.json", () => {
    expect(reviewFiles({ ...good, "package.json": "{nope" }).ok).toBe(false);
    expect(reviewFiles({ ...good, "package.json": "{}" }).ok).toBe(false);
  });

  it("blocks hardcoded secrets", () => {
    const key = "0x" + "a".repeat(64);
    expect(reviewFiles({ ...good, "lib/k.ts": `const k="${key}"` }).ok).toBe(false);
    expect(reviewFiles({ ...good, "lib/k.ts": `const k="-----BEGIN PRIVATE KEY-----"` }).ok).toBe(false);
    expect(reviewFiles({ ...good, "lib/k.ts": `const k="ghp_${"a".repeat(36)}"` }).ok).toBe(false);
    // a 20-byte address is fine
    expect(reviewFiles({ ...good, "lib/a.ts": `const a="0x${"b".repeat(40)}"` }).ok).toBe(true);
  });

  it("blocks eval / child_process in JS-TS, tx.origin in Solidity; warns on selfdestruct", () => {
    expect(reviewFiles({ ...good, "a.ts": "eval('1')" }).ok).toBe(false);
    expect(reviewFiles({ ...good, "a.ts": "import cp from 'child_process'" }).ok).toBe(false);
    expect(reviewFiles({ ...good, "C.sol": "require(tx.origin == owner);" }).ok).toBe(false);
    const warn = reviewFiles({ ...good, "C.sol": "selfdestruct(payable(a));" });
    expect(warn.ok).toBe(true);
    expect(warn.issues[0]?.severity).toBe("warn");
  });

  it("does not apply JS rules to markdown", () => {
    expect(reviewFiles({ ...good, "README.md": "never call eval(" }).ok).toBe(true);
  });
});

describe("isSafePath", () => {
  it.each(["app/page.tsx", "contracts/FeeSplitter.sol", "app/[id]/page.tsx", "public/icon.svg"])("allows %s", (p) =>
    expect(isSafePath(p)).toBe(true));
  it.each(["../etc/passwd", "/abs/path", "a/../b", ".env", "app/.env.local", ".git/config", "a//b", "a b.ts", ""])("blocks %j", (p) =>
    expect(isSafePath(p)).toBe(false));
});
