import { beforeEach, describe, expect, it } from "vitest";
import { decrypt, encrypt } from "@/lib/crypto";
import { _resetRateLimits, rateLimit, sanitizePrompt } from "@/lib/ratelimit";

describe("crypto", () => {
  it("round-trips and uses a fresh IV each time", () => {
    const a = encrypt("whsec_secret");
    const b = encrypt("whsec_secret");
    expect(a).not.toBe(b);
    expect(decrypt(a)).toBe("whsec_secret");
  });
  it("detects tampering", () => {
    const [v, iv, tag, ct] = encrypt("hello").split(":");
    const flipped = Buffer.from(ct!, "base64");
    flipped[0] = flipped[0]! ^ 1;
    expect(() => decrypt([v, iv, tag, flipped.toString("base64")].join(":"))).toThrow();
  });
});

describe("rateLimit (in-memory)", () => {
  beforeEach(_resetRateLimits);
  it("allows up to the limit then returns 429", async () => {
    await rateLimit("k", 2, 1000);
    await rateLimit("k", 2, 1000);
    await expect(rateLimit("k", 2, 1000)).rejects.toMatchObject({ status: 429 });
  });
  it("tracks keys independently", async () => {
    await rateLimit("a", 1, 1000);
    await expect(rateLimit("b", 1, 1000)).resolves.toBeUndefined();
  });
});

describe("sanitizePrompt", () => {
  it("strips control chars and caps length", () => {
    expect(sanitizePrompt("hi\u0000 there\u0007")).toBe("hi there");
    expect(sanitizePrompt("x".repeat(100), 10)).toHaveLength(10);
  });
});
