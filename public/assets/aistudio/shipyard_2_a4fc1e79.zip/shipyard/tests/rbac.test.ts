import { describe, expect, it } from "vitest";
import { assertCanAssign, can } from "@/lib/rbac";

const user = { id: "u1", platformRole: "USER" as const };
const admin = { id: "a1", platformRole: "SUPER_ADMIN" as const };

describe("can()", () => {
  it("super admin can do everything", () => {
    expect(can(admin, "admin_panel")).toBe(true);
    expect(can(admin, "withdraw_wallet")).toBe(true);
  });

  it("regular users never get the admin panel, even as org owner", () => {
    expect(can(user, "admin_panel", { orgRole: "OWNER" })).toBe(false);
  });

  it("signed-in users without a role may only create apps", () => {
    expect(can(user, "create_app")).toBe(true);
    expect(can(user, "deploy")).toBe(false);
    expect(can(user, "view_analytics")).toBe(false);
  });

  it("app owners get owner-level rights", () => {
    expect(can(user, "withdraw_wallet", { isAppOwner: true })).toBe(true);
    expect(can(user, "claim_fees", { isAppOwner: true })).toBe(true);
  });

  it("role matrix: builders deploy but can't move money; admins can't withdraw", () => {
    expect(can(user, "deploy", { orgRole: "BUILDER" })).toBe(true);
    expect(can(user, "claim_fees", { orgRole: "BUILDER" })).toBe(false);
    expect(can(user, "withdraw_wallet", { orgRole: "ADMIN" })).toBe(false);
    expect(can(user, "manage_team", { orgRole: "ADMIN" })).toBe(true);
    expect(can(user, "iterate_app", { orgRole: "VIEWER" })).toBe(false);
  });
});

describe("assertCanAssign()", () => {
  it("only owners can grant or alter the owner role", () => {
    expect(() => assertCanAssign("ADMIN", "OWNER")).toThrow();
    expect(() => assertCanAssign("ADMIN", "VIEWER", "OWNER")).toThrow();
    expect(() => assertCanAssign("OWNER", "OWNER")).not.toThrow();
    expect(() => assertCanAssign("ADMIN", "BUILDER", "VIEWER")).not.toThrow();
  });
});
