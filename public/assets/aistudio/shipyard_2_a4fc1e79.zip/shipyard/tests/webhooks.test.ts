import { describe, expect, it } from "vitest";
import { assertSafeUrl, isPrivateIp, signPayload, verifySignature } from "@/lib/webhooks-core";

describe("webhook signatures", () => {
  const body = JSON.stringify({ event: "app.live" });

  it("round-trips", () => {
    expect(verifySignature("whsec_x", body, signPayload("whsec_x", body))).toBe(true);
  });
  it("rejects wrong secret, tampered body and stale timestamps", () => {
    const sig = signPayload("whsec_x", body);
    expect(verifySignature("whsec_y", body, sig)).toBe(false);
    expect(verifySignature("whsec_x", body + " ", sig)).toBe(false);
    const old = signPayload("whsec_x", body, Math.floor(Date.now() / 1000) - 3600);
    expect(verifySignature("whsec_x", body, old)).toBe(false);
  });
});

describe("SSRF guard", () => {
  it.each(["127.0.0.1", "10.1.2.3", "172.16.0.1", "172.31.255.255", "192.168.1.1", "169.254.169.254", "100.64.0.1", "0.0.0.0", "::1", "fd00::1", "fe80::1", "::ffff:127.0.0.1"])(
    "blocks %s", (ip) => expect(isPrivateIp(ip)).toBe(true));

  it.each(["8.8.8.8", "1.1.1.1", "172.32.0.1", "2606:4700:4700::1111"])(
    "allows %s", (ip) => expect(isPrivateIp(ip)).toBe(false));

  it("rejects non-https, credentials and private literals", async () => {
    const prev = process.env.NODE_ENV;
    (process.env as Record<string, string>).NODE_ENV = "production";
    await expect(assertSafeUrl("http://8.8.8.8/hook")).rejects.toThrow();
    await expect(assertSafeUrl("https://user:pw@8.8.8.8/hook")).rejects.toThrow();
    await expect(assertSafeUrl("https://169.254.169.254/latest/meta-data")).rejects.toThrow();
    await expect(assertSafeUrl("https://[::1]/")).rejects.toThrow();
    await expect(assertSafeUrl("https://8.8.8.8/hook")).resolves.toBeInstanceOf(URL);
    (process.env as Record<string, string>).NODE_ENV = prev ?? "test";
  });
});
