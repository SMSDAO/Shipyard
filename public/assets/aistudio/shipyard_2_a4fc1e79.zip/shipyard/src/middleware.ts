import { NextResponse, type NextRequest } from "next/server";

const SAFE = new Set(["GET", "HEAD", "OPTIONS"]);
// Server-to-server endpoints authenticated by their own secret (signature / bearer), not cookies.
const EXEMPT = ["/api/stripe/webhook", "/api/cron/", "/api/integrations/"];

/**
 * CSRF defense for cookie-authenticated API calls: a mutating request carrying an Origin
 * header must come from our own host. Bearer-token callers (API keys) are not cookie-based
 * and are exempt. Also forwards the HTTP method so API-key read-only scoping can be enforced.
 */
export function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl;

  if (pathname.startsWith("/api/") && !SAFE.has(req.method) && !EXEMPT.some((p) => pathname.startsWith(p))) {
    const bearer = req.headers.get("authorization")?.startsWith("Bearer ");
    const origin = req.headers.get("origin");
    if (!bearer && origin) {
      let host = "";
      try { host = new URL(origin).host; } catch { /* invalid origin falls through to reject */ }
      if (host !== req.headers.get("host")) {
        return NextResponse.json({ error: "Cross-origin request blocked" }, { status: 403 });
      }
    }
  }

  const headers = new Headers(req.headers);
  headers.set("x-sy-method", req.method);
  return NextResponse.next({ request: { headers } });
}

export const config = { matcher: ["/api/:path*"] };
