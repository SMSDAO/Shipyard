/**
 * Pure static review of generated files. Runs before anything is pushed to GitHub or deployed.
 * Errors block the build; warnings are surfaced to the user.
 */
export interface ReviewIssue {
  file: string;
  severity: "error" | "warn";
  message: string;
}

export interface ReviewResult {
  ok: boolean;
  issues: ReviewIssue[];
}

const MAX_FILES = 200;
const MAX_FILE_BYTES = 500_000;
const SAFE_PATH = /^[A-Za-z0-9_\-.@()[\]/]+$/;

const SECRET_PATTERNS: Array<[RegExp, string]> = [
  [/-----BEGIN [A-Z ]*PRIVATE KEY-----/, "private key block"],
  [/\bsk_(?:live|test)_[A-Za-z0-9]{10,}/, "Stripe-style secret key"],
  [/\bAKIA[0-9A-Z]{16}\b/, "AWS access key id"],
  [/\bgh[pousr]_[A-Za-z0-9]{30,}/, "GitHub token"],
  [/\bsk-ant-[A-Za-z0-9_-]{20,}/, "Anthropic API key"],
  [/(?<![0-9a-fA-F])0x[a-fA-F0-9]{64}(?![0-9a-fA-F])/, "possible 32-byte private key"],
];

const CODE_RULES: Array<[RegExp, ReviewIssue["severity"], string, RegExp]> = [
  [/\beval\s*\(/, "error", "eval() is not allowed", /\.(?:[cm]?[jt]sx?)$/],
  [/\bnew\s+Function\s*\(/, "error", "new Function() is not allowed", /\.(?:[cm]?[jt]sx?)$/],
  [/\bchild_process\b/, "error", "child_process is not allowed in generated apps", /\.(?:[cm]?[jt]sx?)$/],
  [/\btx\.origin\b/, "error", "tx.origin must not be used for authorization", /\.sol$/],
  [/\bselfdestruct\s*\(/, "warn", "selfdestruct is deprecated and dangerous", /\.sol$/],
  [/\bdelegatecall\b/, "warn", "delegatecall requires careful review", /\.sol$/],
];

export function isSafePath(p: string): boolean {
  return (
    SAFE_PATH.test(p) &&
    !p.startsWith("/") &&
    !p.split("/").some((seg) => seg === ".." || seg === "." || seg === "") &&
    !/(^|\/)\.env(\.|$)/.test(p) &&
    !/(^|\/)\.git(\/|$)/.test(p)
  );
}

export function reviewFiles(files: Record<string, string>): ReviewResult {
  const issues: ReviewIssue[] = [];
  const add = (file: string, severity: ReviewIssue["severity"], message: string) => issues.push({ file, severity, message });
  const paths = Object.keys(files);

  if (paths.length === 0) add("-", "error", "No files were generated");
  if (paths.length > MAX_FILES) add("-", "error", `Too many files (${paths.length} > ${MAX_FILES})`);

  for (const [path, content] of Object.entries(files)) {
    if (!isSafePath(path)) {
      add(path, "error", "Unsafe or disallowed file path");
      continue;
    }
    if (typeof content !== "string") {
      add(path, "error", "File content must be a string");
      continue;
    }
    if (Buffer.byteLength(content) > MAX_FILE_BYTES) add(path, "error", "File exceeds 500 KB");

    for (const [re, label] of SECRET_PATTERNS) {
      if (re.test(content)) add(path, "error", `Possible hardcoded secret: ${label}`);
    }
    for (const [re, severity, message, appliesTo] of CODE_RULES) {
      if (appliesTo.test(path) && re.test(content)) add(path, severity, message);
    }
  }

  const pkg = files["package.json"];
  if (pkg === undefined) {
    add("package.json", "error", "Missing package.json");
  } else {
    try {
      const parsed = JSON.parse(pkg) as { dependencies?: Record<string, string> };
      if (!parsed.dependencies?.next) add("package.json", "error", "package.json must depend on next");
    } catch {
      add("package.json", "error", "package.json is not valid JSON");
    }
  }
  if (!paths.some((p) => /^(?:src\/)?app\/page\.(?:tsx|jsx|js)$/.test(p))) {
    add("app/page.tsx", "error", "Missing app/page entry point");
  }

  return { ok: !issues.some((i) => i.severity === "error"), issues };
}
