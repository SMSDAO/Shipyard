import { db } from "@/lib/db";
import { COSTS, spendCredits } from "@/lib/credits";
import { audit } from "@/lib/audit";
import { emitForApp } from "@/lib/webhooks";
import { contractTemplate, generateNextjsFiles } from "./codegen";
import { reviewFiles, type ReviewResult } from "./reviewer";
import { DEFAULT_PLAN, type BuildPlan } from "./roles";
import {
  createAppWallet,
  createGithubRepo,
  createVercelProject,
  farcasterManifest,
  launchToken,
} from "@/lib/services/providers";

export interface ToolContext {
  appId: string;
  userId: string;
  buildId: string;
  /** Mutable scratch space shared across tool calls in one build. */
  state: { files?: Record<string, string>; answers?: string; plan?: BuildPlan; review?: ReviewResult };
}

type ToolFn = (args: Record<string, unknown>, ctx: ToolContext) => Promise<unknown>;

async function setStatus(ctx: ToolContext, status: "CLARIFYING" | "GENERATING" | "DEPLOYING" | "LIVE" | "FAILED", step: string) {
  await db.$transaction([
    db.app.update({ where: { id: ctx.appId }, data: { status } }),
    db.buildJob.update({ where: { id: ctx.buildId }, data: { status, step } }),
  ]);
}

export const TOOLS: Record<string, ToolFn> = {
  async ask_clarifying_questions(args, ctx) {
    await setStatus(ctx, "CLARIFYING", "Asking clarifying questions");
    await spendCredits(ctx.userId, COSTS.clarify, "Clarifying questions");
    return { questions: args.questions ?? [] };
  },

  async set_build_plan(args, ctx) {
    const sym = typeof args.tokenSymbol === "string" && /^[A-Za-z]{3,5}$/.test(args.tokenSymbol) ? args.tokenSymbol.toUpperCase() : undefined;
    ctx.state.plan = {
      needsContracts: args.needsContracts === undefined ? DEFAULT_PLAN.needsContracts : args.needsContracts === true,
      launchToken: args.launchToken === true,
      tokenSymbol: sym,
    };
    return ctx.state.plan;
  },

  async review_code(_args, ctx) {
    ctx.state.review = reviewFiles(ctx.state.files ?? {});
    return ctx.state.review;
  },

  async generate_brand_assets(_args, ctx) {
    const app = await db.app.findUniqueOrThrow({ where: { id: ctx.appId } });
    const hue = [...app.name].reduce((h, c) => (h * 31 + c.charCodeAt(0)) % 360, 7);
    const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128"><rect width="128" height="128" rx="28" fill="hsl(${hue} 70% 45%)"/><text x="64" y="82" font-size="56" text-anchor="middle" fill="#fff" font-family="sans-serif">${app.name[0]?.toUpperCase() ?? "S"}</text></svg>`;
    const logoUrl = `data:image/svg+xml;base64,${Buffer.from(svg).toString("base64")}`;
    await db.app.update({ where: { id: ctx.appId }, data: { logoUrl } });
    return { logoUrl: "generated" };
  },

  async generate_nextjs_code(_args, ctx) {
    await setStatus(ctx, "GENERATING", "Generating Next.js code");
    await spendCredits(ctx.userId, COSTS.generate, "Code generation");
    const app = await db.app.findUniqueOrThrow({ where: { id: ctx.appId } });
    ctx.state.files = await generateNextjsFiles(app.name, app.idea, ctx.state.answers ?? "");
    return { files: Object.keys(ctx.state.files) };
  },

  async generate_smart_contracts(_args, ctx) {
    const app = await db.app.findUniqueOrThrow({ where: { id: ctx.appId } });
    ctx.state.files = { ...(ctx.state.files ?? {}), "contracts/FeeSplitter.sol": contractTemplate(app.name) };
    return { added: "contracts/FeeSplitter.sol" };
  },

  async create_github_repo(_args, ctx) {
    const app = await db.app.findUniqueOrThrow({ where: { id: ctx.appId } });
    const repo = await createGithubRepo(app.slug, ctx.state.files ?? {});
    await db.app.update({ where: { id: ctx.appId }, data: { repoUrl: repo.url } });
    return repo;
  },

  async create_vercel_project(_args, ctx) {
    await setStatus(ctx, "DEPLOYING", "Deploying to Vercel");
    await spendCredits(ctx.userId, COSTS.deploy, "Deployment");
    const app = await db.app.findUniqueOrThrow({ where: { id: ctx.appId } });
    const project = await createVercelProject(app.slug, app.repoUrl ?? "");
    await db.app.update({ where: { id: ctx.appId }, data: { vercelId: project.id, liveUrl: project.url } });
    return project;
  },

  async create_app_wallet(_args, ctx) {
    const existing = await db.appWallet.findUnique({ where: { appId: ctx.appId } });
    if (existing) return { address: existing.address };
    const w = await createAppWallet();
    await db.appWallet.create({ data: { appId: ctx.appId, address: w.address, providerRef: w.providerRef } });
    return { address: w.address };
  },

  async launch_token(args, ctx) {
    await spendCredits(ctx.userId, COSTS.token, "Token launch");
    const app = await db.app.findUniqueOrThrow({ where: { id: ctx.appId }, include: { wallet: true } });
    const symbol = String(args.symbol ?? app.name.replace(/\W/g, "").slice(0, 5)).toUpperCase();
    const t = await launchToken(symbol, `${app.name} Token`, app.wallet?.address ?? "");
    await db.token.upsert({
      where: { appId: ctx.appId },
      update: {},
      create: { appId: ctx.appId, symbol, name: t.name, contract: t.contract, creatorShareBps: t.creatorShareBps },
    });
    await audit(ctx.userId, "token.launch", ctx.appId);
    return { symbol, contract: t.contract };
  },

  async deploy_farcaster_manifest(_args, ctx) {
    const app = await db.app.findUniqueOrThrow({ where: { id: ctx.appId } });
    const manifest = farcasterManifest(app.name, app.liveUrl ?? "https://example.app");
    await db.platformIntegration.upsert({
      where: { appId_kind: { appId: ctx.appId, kind: "FARCASTER" } },
      update: { enabled: true, config: manifest },
      create: { appId: ctx.appId, kind: "FARCASTER", enabled: true, config: manifest },
    });
    return { enabled: true };
  },

  async update_app_status(args, ctx) {
    const status = args.status === "FAILED" ? "FAILED" : "LIVE";
    await setStatus(ctx, status, status === "LIVE" ? "Live" : "Failed");
    await emitForApp(ctx.appId, status === "LIVE" ? "app.live" : "app.failed");
    return { status };
  },
};

/** JSON-schema tool definitions exposed to the model. */
export const TOOL_DEFS = [
  { name: "set_build_plan", description: "Record the build plan once questions are settled.", input_schema: { type: "object", properties: { needsContracts: { type: "boolean" }, launchToken: { type: "boolean" }, tokenSymbol: { type: "string" } }, required: ["needsContracts", "launchToken"] } },
  { name: "review_code", description: "Static review of generated files (secrets, unsafe APIs, structure).", input_schema: { type: "object", properties: {} } },
  { name: "ask_clarifying_questions", description: "Ask the user 3-7 clarifying questions (audience, features, monetization, design, platforms).", input_schema: { type: "object", properties: { questions: { type: "array", items: { type: "string" } } }, required: ["questions"] } },
  { name: "generate_brand_assets", description: "Generate logo and brand kit.", input_schema: { type: "object", properties: {} } },
  { name: "generate_nextjs_code", description: "Generate the Next.js app source.", input_schema: { type: "object", properties: {} } },
  { name: "generate_smart_contracts", description: "Add Solidity contracts when onchain logic is needed.", input_schema: { type: "object", properties: {} } },
  { name: "create_github_repo", description: "Create the GitHub repository with generated files.", input_schema: { type: "object", properties: {} } },
  { name: "create_vercel_project", description: "Create and deploy the Vercel project.", input_schema: { type: "object", properties: {} } },
  { name: "create_app_wallet", description: "Create the app's dedicated wallet.", input_schema: { type: "object", properties: {} } },
  { name: "launch_token", description: "Launch the app token (creator earns 60% of trading fees). Only if the user chose token funding.", input_schema: { type: "object", properties: { symbol: { type: "string" } } } },
  { name: "deploy_farcaster_manifest", description: "Publish the Farcaster mini app manifest.", input_schema: { type: "object", properties: {} } },
  { name: "update_app_status", description: "Mark the build LIVE or FAILED.", input_schema: { type: "object", properties: { status: { type: "string", enum: ["LIVE", "FAILED"] } }, required: ["status"] } },
] as const;
