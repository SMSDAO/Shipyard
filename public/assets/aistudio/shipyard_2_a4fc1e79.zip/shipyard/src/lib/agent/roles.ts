export type RoleName = "planner" | "designer" | "coder" | "reviewer" | "deployer";

export interface Role {
  title: string;
  /** What the user sees as the build step. */
  step: string;
  /** Only these tools can be executed by this agent (enforced in the loop, not just prompted). */
  tools: readonly string[];
  /** System prompt for roles driven by the model. */
  prompt?: string;
}

export const ROLES: Record<RoleName, Role> = {
  planner: {
    title: "Planner",
    step: "Planner: understanding your idea",
    tools: ["ask_clarifying_questions", "set_build_plan"],
    prompt: `You are the Planner for Shipyard, a platform that turns an idea into a deployed onchain miniapp.
1. If you still lack key details, call ask_clarifying_questions with 3-7 concise questions (target audience, core features,
   monetization, design style, platform priority). Ask at most once; the tool is unavailable after that.
2. If the user says "surprise me", or has answered, skip questions.
3. Then call set_build_plan exactly once: needsContracts (true only if the idea needs onchain logic beyond a wallet),
   launchToken (true only if the user chose token funding), tokenSymbol (3-5 letters, optional).
Reply in the user's language. Never invent details the user did not give.`,
  },
  designer: { title: "Designer", step: "Designer: creating brand kit", tools: ["generate_brand_assets"] },
  coder: { title: "Coder", step: "Coder: generating the app", tools: ["generate_nextjs_code", "generate_smart_contracts"] },
  reviewer: { title: "Reviewer", step: "Reviewer: checking generated code", tools: ["review_code"] },
  deployer: {
    title: "Deployer",
    step: "Deployer: shipping to production",
    tools: ["create_github_repo", "create_vercel_project", "create_app_wallet", "launch_token", "deploy_farcaster_manifest", "update_app_status"],
  },
};

export interface BuildPlan {
  needsContracts: boolean;
  launchToken: boolean;
  tokenSymbol?: string;
}

export const DEFAULT_PLAN: BuildPlan = { needsContracts: true, launchToken: false };

/** Pure: the ordered tool calls the deterministic agents run for a given plan. */
export function stepsFor(role: Exclude<RoleName, "planner">, plan: BuildPlan): Array<{ tool: string; args?: Record<string, unknown> }> {
  switch (role) {
    case "designer":
      return [{ tool: "generate_brand_assets" }];
    case "coder":
      return [{ tool: "generate_nextjs_code" }, ...(plan.needsContracts ? [{ tool: "generate_smart_contracts" }] : [])];
    case "reviewer":
      return [{ tool: "review_code" }];
    case "deployer":
      return [
        { tool: "create_github_repo" },
        { tool: "create_vercel_project" },
        { tool: "create_app_wallet" },
        ...(plan.launchToken ? [{ tool: "launch_token", args: { symbol: plan.tokenSymbol } }] : []),
        { tool: "deploy_farcaster_manifest" },
        { tool: "update_app_status", args: { status: "LIVE" } },
      ];
  }
}
