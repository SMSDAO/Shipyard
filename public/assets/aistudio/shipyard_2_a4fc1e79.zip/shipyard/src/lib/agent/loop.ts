import { db } from "@/lib/db";
import { COSTS, grantCredits } from "@/lib/credits";
import { emitForApp } from "@/lib/webhooks";
import { TOOLS, TOOL_DEFS, type ToolContext } from "./tools";
import { DEFAULT_PLAN, ROLES, stepsFor, type RoleName } from "./roles";

const MAX_STEPS = 8;
const hasModel = () => !!process.env.ANTHROPIC_API_KEY;

interface Block { type: string; text?: string; id?: string; name?: string; input?: Record<string, unknown> }
interface Msg { role: "user" | "assistant"; content: unknown }

async function callModel(system: string, toolNames: readonly string[], messages: Msg[]) {
  const res = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: { "x-api-key": process.env.ANTHROPIC_API_KEY!, "anthropic-version": "2023-06-01", "content-type": "application/json" },
    body: JSON.stringify({
      model: process.env.AGENT_MODEL ?? "claude-sonnet-4-5",
      max_tokens: 2048,
      system,
      tools: TOOL_DEFS.filter((t) => toolNames.includes(t.name)),
      messages,
    }),
    signal: AbortSignal.timeout(120_000),
  });
  if (!res.ok) throw new Error(`Model error ${res.status}`);
  return (await res.json()) as { content: Block[]; stop_reason: string };
}

async function setStep(ctx: ToolContext, step: string) {
  await db.buildJob.update({ where: { id: ctx.buildId }, data: { step } });
}

/** Runs one tool on behalf of a role. The allow-list is enforced here, regardless of what the model asks for. */
async function runTool(role: RoleName, name: string, args: Record<string, unknown>, ctx: ToolContext, convoId: string) {
  if (!ROLES[role].tools.includes(name)) return { error: `Tool ${name} is not available to the ${ROLES[role].title}` };
  let out: unknown;
  try {
    out = await TOOLS[name]!(args, ctx);
  } catch (e) {
    if ((e as { status?: number }).status === 402) throw e; // credit problems go straight to the user
    out = { error: (e as Error).message };
  }
  await db.message.create({ data: { conversationId: convoId, role: "TOOL", toolName: `${role}:${name}`, content: JSON.stringify(out).slice(0, 4000) } });
  return out;
}

/** Model-driven agent loop (Planner). Returns questions if the agent paused to ask them. */
async function runModelAgent(role: RoleName, ctx: ToolContext, convoId: string, messages: Msg[], allowed: readonly string[]) {
  const system = ROLES[role].prompt ?? "";
  for (let step = 0; step < MAX_STEPS; step++) {
    const data = await callModel(system, allowed, messages);
    messages.push({ role: "assistant", content: data.content });
    const text = data.content.filter((b) => b.type === "text").map((b) => b.text).join("");
    const calls = data.content.filter((b) => b.type === "tool_use");

    const results: unknown[] = [];
    for (const c of calls) {
      const out = allowed.includes(c.name!) ? await runTool(role, c.name!, c.input ?? {}, ctx, convoId) : { error: "tool not available" };
      results.push({ type: "tool_result", tool_use_id: c.id, content: JSON.stringify(out) });
      if (c.name === "ask_clarifying_questions") {
        const qs = ((out as { questions?: string[] }).questions ?? []).map((q, i) => `${i + 1}. ${q}`).join("\n");
        await db.message.create({ data: { conversationId: convoId, role: "ASSISTANT", content: qs } });
        return { questions: qs };
      }
    }
    if (text) await db.message.create({ data: { conversationId: convoId, role: "ASSISTANT", content: text } });
    if (data.stop_reason !== "tool_use" || calls.length === 0 || ctx.state.plan) return { questions: null };
    messages.push({ role: "user", content: results });
  }
  return { questions: null };
}

/** Deterministic agent: runs the role's fixed steps for the plan. */
async function runRole(role: Exclude<RoleName, "planner">, ctx: ToolContext, convoId: string) {
  await setStep(ctx, ROLES[role].step);
  for (const s of stepsFor(role, ctx.state.plan ?? DEFAULT_PLAN)) {
    const out = await runTool(role, s.tool, s.args ?? {}, ctx, convoId);
    if ((out as { error?: string })?.error) throw new Error(`${ROLES[role].title}: ${(out as { error: string }).error}`);
  }
}

/**
 * Pipeline: Planner (model) → Designer → Coder → Reviewer (gate) → Deployer.
 * Every message is persisted so a build can pause for questions, resume, and be iterated after launch.
 */
export async function runAgentTurn(opts: { appId: string; userId: string; userMessage: string }) {
  const convo = await db.conversation.upsert({ where: { appId: opts.appId }, update: {}, create: { appId: opts.appId } });
  await db.message.create({ data: { conversationId: convo.id, role: "USER", content: opts.userMessage } });

  const job = await db.buildJob.create({ data: { appId: opts.appId } });
  const ctx: ToolContext = { appId: opts.appId, userId: opts.userId, buildId: job.id, state: {} };

  const history = await db.message.findMany({ where: { conversationId: convo.id }, orderBy: { createdAt: "asc" } });
  ctx.state.answers = history.filter((m) => m.role === "USER").map((m) => m.content).join("\n");
  const alreadyAsked = history.some((m) => m.role === "TOOL" && m.toolName?.endsWith("ask_clarifying_questions"));

  let reply = "";
  let charged = 0;
  try {
    // 1. Planner — only place the model decides things; skipped offline (defaults apply).
    if (hasModel()) {
      const messages: Msg[] = history
        .filter((m) => m.role === "USER" || m.role === "ASSISTANT")
        .map((m) => ({ role: m.role === "USER" ? "user" : "assistant", content: m.content }));
      const allowed = ROLES.planner.tools.filter((t) => !(alreadyAsked && t === "ask_clarifying_questions"));
      await setStep(ctx, ROLES.planner.step);
      const { questions } = await runModelAgent("planner", ctx, convo.id, messages, allowed);
      if (questions) return { reply: questions, buildId: job.id, paused: true };
    }
    ctx.state.plan ??= DEFAULT_PLAN;

    // 2. Designer → Coder
    await runRole("designer", ctx, convo.id);
    await runRole("coder", ctx, convo.id);
    charged = COSTS.generate;

    // 3. Reviewer gate: nothing unsafe reaches GitHub or Vercel. Code generation credits are refunded on rejection.
    await runRole("reviewer", ctx, convo.id);
    if (!ctx.state.review?.ok) {
      await grantCredits(opts.userId, charged, "Refund: generated code failed review");
      charged = 0;
      const why = ctx.state.review?.issues.filter((i) => i.severity === "error").map((i) => `${i.file}: ${i.message}`).slice(0, 5).join("; ");
      throw Object.assign(new Error(`Generated code failed review (${why}). Credits refunded — try rephrasing the idea.`), { status: 422 });
    }

    // 4. Deployer
    await runRole("deployer", ctx, convo.id);
    const n = (await db.appVersion.count({ where: { appId: opts.appId } })) + 1;
    await db.appVersion.create({ data: { appId: opts.appId, number: n, summary: opts.userMessage.slice(0, 200) } });

    const warns = ctx.state.review.issues.filter((i) => i.severity === "warn").length;
    reply = `Your app is live.${warns ? ` The reviewer left ${warns} warning${warns > 1 ? "s" : ""} on the generated code.` : ""}${hasModel() ? "" : " (Offline mode: set ANTHROPIC_API_KEY for the conversational planner.)"}`;
    await db.message.create({ data: { conversationId: convo.id, role: "ASSISTANT", content: reply } });
  } catch (e) {
    const message = (e as Error).message;
    await db.$transaction([
      db.buildJob.update({ where: { id: job.id }, data: { status: "FAILED", error: message.slice(0, 500) } }),
      db.app.update({ where: { id: opts.appId }, data: { status: "FAILED" } }),
    ]);
    await emitForApp(opts.appId, "app.failed", { reason: message.slice(0, 200) });
    throw e;
  }
  return { reply, buildId: job.id, paused: false };
}
