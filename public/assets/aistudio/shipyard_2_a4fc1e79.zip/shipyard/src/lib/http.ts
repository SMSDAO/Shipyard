import { randomUUID } from "node:crypto";
import { NextResponse } from "next/server";
import { ZodError } from "zod";

/** Structured JSON logs (one line per event) — ingestible by Datadog/Logtail/Vercel log drains. */
export function log(level: "info" | "warn" | "error", msg: string, extra: Record<string, unknown> = {}) {
  console[level === "info" ? "log" : level](JSON.stringify({ level, msg, ts: new Date().toISOString(), ...extra }));
}

export function handle<T>(fn: () => Promise<T>) {
  const requestId = randomUUID();
  return fn()
    .then((data) => NextResponse.json(data, { headers: { "x-request-id": requestId } }))
    .catch((e: unknown) => {
      if (e instanceof ZodError) {
        return NextResponse.json({ error: "Invalid input", issues: e.flatten(), requestId }, { status: 400, headers: { "x-request-id": requestId } });
      }
      const err = e as { status?: number; message?: string };
      const status = err.status ?? 500;
      if (status >= 500) log("error", "unhandled error", { requestId, err: String(e), stack: (e as Error).stack });
      return NextResponse.json(
        { error: status >= 500 ? "Internal error" : err.message, requestId },
        { status, headers: { "x-request-id": requestId, ...(status === 429 ? { "retry-after": "60" } : {}) } },
      );
    });
}

export const httpError = (status: number, message: string) => Object.assign(new Error(message), { status });
