import { db } from "./db";

export const COSTS = {
  clarify: 5,
  generate: 120,
  deploy: 40,
  token: 25,
  iterate: 30,
} as const;

/** Atomically deduct credits before an expensive operation. Throws 402 if insufficient. */
export async function spendCredits(userId: string, amount: number, reason: string) {
  return db.$transaction(async (tx) => {
    const res = await tx.user.updateMany({
      where: { id: userId, credits: { gte: amount } },
      data: { credits: { decrement: amount } },
    });
    if (res.count === 0) throw Object.assign(new Error("Insufficient credits"), { status: 402 });
    await tx.creditTransaction.create({ data: { userId, type: "SPEND", amount: -amount, reason } });
  });
}

export async function grantCredits(userId: string, amount: number, reason: string, type: "PURCHASE" | "GRANT" = "GRANT") {
  await db.$transaction([
    db.user.update({ where: { id: userId }, data: { credits: { increment: amount } } }),
    db.creditTransaction.create({ data: { userId, type, amount, reason } }),
  ]);
}
