import type { OrgRole, PlatformRole } from "@prisma/client";

export const PERMISSIONS = [
  "create_app",
  "deploy",
  "iterate_app",
  "claim_fees",
  "withdraw_wallet",
  "manage_team",
  "view_analytics",
  "manage_billing",
  "manage_platforms",
  "admin_panel",
] as const;
export type Permission = (typeof PERMISSIONS)[number];

/** Role → permission matrix. App owners get OWNER-level rights on their own apps. */
export const ROLE_PERMISSIONS: Record<OrgRole, readonly Permission[]> = {
  OWNER: [
    "create_app", "deploy", "iterate_app", "claim_fees", "withdraw_wallet",
    "manage_team", "view_analytics", "manage_billing", "manage_platforms",
  ],
  ADMIN: [
    "create_app", "deploy", "iterate_app", "claim_fees", "manage_team",
    "view_analytics", "manage_platforms",
  ],
  BUILDER: ["create_app", "deploy", "iterate_app", "view_analytics"],
  VIEWER: ["view_analytics"],
};

export interface Actor {
  id: string;
  platformRole: PlatformRole;
}

export function can(
  actor: Actor,
  permission: Permission,
  scope?: { orgRole?: OrgRole | null; isAppOwner?: boolean },
): boolean {
  if (actor.platformRole === "SUPER_ADMIN") return true;
  if (permission === "admin_panel") return false;
  const role: OrgRole | null = scope?.isAppOwner ? "OWNER" : (scope?.orgRole ?? null);
  if (!role) return permission === "create_app"; // any signed-in user may create personal apps
  return ROLE_PERMISSIONS[role].includes(permission);
}

export class ForbiddenError extends Error {
  status = 403;
  constructor(permission: Permission) {
    super(`Missing permission: ${permission}`);
  }
}

export function assertCan(...args: Parameters<typeof can>) {
  if (!can(...args)) throw new ForbiddenError(args[1]);
}

export const ROLE_RANK: Record<OrgRole, number> = { VIEWER: 0, BUILDER: 1, ADMIN: 2, OWNER: 3 };

/** Admins can manage up to ADMIN; only OWNERs can grant, change or remove OWNER. */
export function assertCanAssign(actorRole: OrgRole | undefined, target: OrgRole, current?: OrgRole) {
  const actor = actorRole ?? "OWNER"; // super admins pass actorRole undefined
  if ((target === "OWNER" || current === "OWNER") && actor !== "OWNER") {
    throw Object.assign(new Error("Only owners can grant or change the owner role"), { status: 403 });
  }
}
