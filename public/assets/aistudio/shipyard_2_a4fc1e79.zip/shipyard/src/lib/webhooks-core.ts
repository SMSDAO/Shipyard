import { createHmac, timingSafeEqual } from "node:crypto";
import { lookup } from "node:dns/promises";
import { isIP } from "node:net";

/** Stripe-style signature: `t=<unix>,v1=<hex hmac-sha256 of "t.body">`. */
export function signPayload(secret: string, body: string, t = Math.floor(Date.now() / 1000)) {
  const v1 = createHmac("sha256", secret).update(`${t}.${body}`).digest("hex");
  return `t=${t},v1=${v1}`;
}

/** For customers verifying our deliveries (also used in tests). */
export function verifySignature(secret: string, body: string, header: string, toleranceSec = 300) {
  const parts = Object.fromEntries(header.split(",").map((p) => p.split("=") as [string, string]));
  const t = Number(parts.t);
  if (!t || !parts.v1 || Math.abs(Date.now() / 1000 - t) > toleranceSec) return false;
  const expected = signPayload(secret, body, t).split("v1=")[1]!;
  const a = Buffer.from(expected);
  const b = Buffer.from(parts.v1);
  return a.length === b.length && timingSafeEqual(a, b);
}

export function isPrivateIp(ip: string): boolean {
  const v = isIP(ip);
  if (v === 4) {
    const [a, b] = ip.split(".").map(Number) as [number, number];
    return (
      a === 0 || a === 10 || a === 127 || a >= 224 ||
      (a === 169 && b === 254) ||
      (a === 172 && b >= 16 && b <= 31) ||
      (a === 192 && b === 168) ||
      (a === 100 && b >= 64 && b <= 127)
    );
  }
  if (v === 6) {
    const l = ip.toLowerCase();
    if (l === "::1" || l === "::") return true;
    if (l.startsWith("::ffff:")) return isPrivateIp(l.slice(7));
    return l.startsWith("fc") || l.startsWith("fd") || l.startsWith("fe8") || l.startsWith("fe9") || l.startsWith("fea") || l.startsWith("feb");
  }
  return true; // not an IP literal we understand → treat as unsafe
}

/**
 * SSRF guard for customer-supplied webhook URLs: https only (http allowed outside production),
 * and every resolved address must be public. Note: resolution here and at fetch time are separate
 * lookups, so for strict environments also run delivery behind an egress proxy that blocks private ranges.
 */
export async function assertSafeUrl(raw: string) {
  let u: URL;
  try { u = new URL(raw); } catch { throw Object.assign(new Error("Invalid URL"), { status: 400 }); }
  const prod = process.env.NODE_ENV === "production";
  if (u.protocol !== "https:" && (prod || u.protocol !== "http:")) {
    throw Object.assign(new Error("Webhook URL must use https"), { status: 400 });
  }
  if (u.username || u.password) throw Object.assign(new Error("Credentials in URL not allowed"), { status: 400 });
  const host = u.hostname.replace(/^\[|\]$/g, "");
  const addrs = isIP(host) ? [{ address: host }] : await lookup(host, { all: true }).catch(() => []);
  if (addrs.length === 0 || addrs.some((a) => isPrivateIp(a.address))) {
    throw Object.assign(new Error("Webhook URL must resolve to a public address"), { status: 400 });
  }
  return u;
}

export const WEBHOOK_EVENTS = [
  "*", "app.live", "app.failed", "wallet.withdrawal", "fees.claimed", "member.added", "member.removed",
] as const;
export type WebhookEvent = (typeof WEBHOOK_EVENTS)[number];

/** Seconds to wait before retry N (index = attempts already made). 6 attempts total. */
export const BACKOFF_SECONDS = [60, 300, 1800, 7200, 43200];
