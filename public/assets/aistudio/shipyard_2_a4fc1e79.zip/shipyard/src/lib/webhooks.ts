import { db } from "./db";
import { decrypt } from "./crypto";
import { log } from "./http";
import { BACKOFF_SECONDS, assertSafeUrl, signPayload } from "./webhooks-core";

/** Queue + immediately attempt delivery to every matching endpoint in the org. Never throws. */
export async function emit(orgId: string, event: string, data: Record<string, unknown>) {
  try {
    const endpoints = await db.webhookEndpoint.findMany({
      where: { orgId, enabled: true, OR: [{ events: { has: event } }, { events: { has: "*" } }] },
    });
    const deliveries = await Promise.all(
      endpoints.map((e) =>
        db.webhookDelivery.create({
          data: { endpointId: e.id, event, payload: { event, createdAt: new Date().toISOString(), data }, nextAttemptAt: new Date() },
        }),
      ),
    );
    await Promise.allSettled(deliveries.map((d) => attempt(d.id)));
  } catch (e) {
    log("error", "webhook emit failed", { orgId, event, err: String(e) });
  }
}

export async function emitForApp(appId: string, event: string, data: Record<string, unknown> = {}) {
  const app = await db.app.findUnique({ where: { id: appId }, select: { orgId: true, id: true, name: true, slug: true, liveUrl: true } });
  if (app?.orgId) await emit(app.orgId, event, { app: { id: app.id, name: app.name, slug: app.slug, liveUrl: app.liveUrl }, ...data });
}

export async function attempt(deliveryId: string) {
  const d = await db.webhookDelivery.findUnique({ where: { id: deliveryId }, include: { endpoint: true } });
  if (!d || d.deliveredAt) return;

  const body = JSON.stringify({ id: d.id, ...(d.payload as object) });
  let status: number | null = null;
  let error: string | null = null;
  try {
    await assertSafeUrl(d.endpoint.url);
    const res = await fetch(d.endpoint.url, {
      method: "POST",
      redirect: "manual", // never follow redirects into internal hosts
      signal: AbortSignal.timeout(8000),
      headers: {
        "Content-Type": "application/json",
        "User-Agent": "Shipyard-Webhooks/1",
        "X-Shipyard-Event": d.event,
        "X-Shipyard-Delivery": d.id,
        "X-Shipyard-Signature": signPayload(decrypt(d.endpoint.secretEnc), body),
      },
      body,
    });
    status = res.status;
    if (res.status < 200 || res.status >= 300) error = `HTTP ${res.status}`;
  } catch (e) {
    error = (e as Error).message.slice(0, 200);
  }

  const attempts = d.attempts + 1;
  if (!error) {
    await db.webhookDelivery.update({ where: { id: d.id }, data: { attempts, lastStatus: status, lastError: null, deliveredAt: new Date(), nextAttemptAt: null } });
    return;
  }
  const delay = BACKOFF_SECONDS[attempts - 1];
  await db.webhookDelivery.update({
    where: { id: d.id },
    data: { attempts, lastStatus: status, lastError: error, nextAttemptAt: delay ? new Date(Date.now() + delay * 1000) : null },
  });
}

/** Called by the cron route: retry due deliveries, claiming each row first to avoid double-sends. */
export async function processDue(limit = 50) {
  const due = await db.webhookDelivery.findMany({
    where: { deliveredAt: null, nextAttemptAt: { lte: new Date() } },
    orderBy: { nextAttemptAt: "asc" },
    take: limit,
  });
  let sent = 0;
  for (const d of due) {
    const claimed = await db.webhookDelivery.updateMany({
      where: { id: d.id, nextAttemptAt: d.nextAttemptAt },
      data: { nextAttemptAt: new Date(Date.now() + 5 * 60_000) },
    });
    if (claimed.count === 0) continue;
    await attempt(d.id);
    sent++;
  }
  return sent;
}
