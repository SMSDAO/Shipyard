import { createHash, randomBytes } from "node:crypto";
import { SignJWT, jwtVerify } from "jose";
import { cookies, headers } from "next/headers";
import { db } from "./db";

const COOKIE = "sy_session";

function secret() {
  const s = process.env.AUTH_SECRET;
  if (!s && process.env.NODE_ENV === "production") throw new Error("AUTH_SECRET is required in production");
  return new TextEncoder().encode(s ?? "dev-only-secret-change-me");
}

export const hashKey = (k: string) => createHash("sha256").update(k).digest("hex");

/** Returns { key, prefix, hash }. Show `key` to the user once; store only prefix + hash. */
export function generateApiKey() {
  const key = `sk_live_${randomBytes(32).toString("base64url")}`;
  return { key, prefix: key.slice(0, 12), hash: hashKey(key) };
}

export async function createSession(userId: string) {
  const token = await new SignJWT({ sub: userId })
    .setProtectedHeader({ alg: "HS256" })
    .setIssuedAt()
    .setExpirationTime("30d")
    .sign(secret());
  (await cookies()).set(COOKIE, token, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    maxAge: 60 * 60 * 24 * 30,
  });
}

export async function clearSession() {
  (await cookies()).delete(COOKIE);
}

async function userFromApiKey(raw: string) {
  const key = await db.apiKey.findUnique({ where: { hash: hashKey(raw) }, include: { user: true } });
  if (!key || key.revokedAt || (key.expiresAt && key.expiresAt < new Date())) return null;
  const method = (await headers()).get("x-sy-method") ?? "GET";
  if (key.readOnly && !["GET", "HEAD"].includes(method)) {
    throw Object.assign(new Error("API key is read-only"), { status: 403 });
  }
  // Best-effort usage stamp; never block the request on it.
  void db.apiKey.update({ where: { id: key.id }, data: { lastUsedAt: new Date() } }).catch(() => {});
  return key.user;
}

/** Signed-in user via `Authorization: Bearer sk_…` API key or the session cookie; null if neither. */
export async function getUser() {
  const auth = (await headers()).get("authorization");
  if (auth?.startsWith("Bearer sk_")) return userFromApiKey(auth.slice(7).trim());

  const token = (await cookies()).get(COOKIE)?.value;
  if (!token) return null;
  try {
    const { payload } = await jwtVerify(token, secret());
    return db.user.findUnique({ where: { id: String(payload.sub) } });
  } catch {
    return null;
  }
}

export async function requireUser() {
  const user = await getUser();
  if (!user) throw Object.assign(new Error("Unauthorized"), { status: 401 });
  return user;
}
