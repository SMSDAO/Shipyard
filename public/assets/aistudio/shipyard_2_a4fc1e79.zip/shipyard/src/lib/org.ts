import type { OrgRole, User } from "@prisma/client";
import { db } from "./db";
import { assertCan, type Permission } from "./rbac";
import { httpError } from "./http";

/** Loads the caller's membership and enforces `permission`. Non-members get 404 (don't leak org existence). */
export async function requireOrg(user: User, orgId: string, permission: Permission) {
  const m = await db.membership.findUnique({ where: { userId_orgId: { userId: user.id, orgId } } });
  if (!m && user.platformRole !== "SUPER_ADMIN") throw httpError(404, "Not found");
  assertCan(user, permission, { orgRole: m?.role });
  return m;
}

export { assertCanAssign, ROLE_RANK } from "./rbac";

export async function assertNotLastOwner(orgId: string, userId: string) {
  const owners = await db.membership.findMany({ where: { orgId, role: "OWNER" } });
  if (owners.length === 1 && owners[0]!.userId === userId) throw httpError(400, "An organization must keep at least one owner");
}
