/**
 * External provider adapters. Each uses the real API when its env vars are present
 * and otherwise returns a deterministic mock so the full flow works locally.
 */
import { randomBytes } from "node:crypto";
import { isSafePath } from "@/lib/agent/reviewer";

const hex = (n: number) => randomBytes(n).toString("hex");

export async function createGithubRepo(slug: string, files: Record<string, string>) {
  const token = process.env.GITHUB_TOKEN;
  const owner = process.env.GITHUB_OWNER;
  if (!token || !owner) return { url: `https://github.com/mock-org/${slug}`, mocked: true };

  const headers = { Authorization: `Bearer ${token}`, Accept: "application/vnd.github+json", "Content-Type": "application/json" };
  const create = await fetch(`https://api.github.com/orgs/${owner}/repos`, {
    method: "POST",
    headers,
    body: JSON.stringify({ name: slug, private: true, auto_init: true }),
  });
  // 422 = repo already exists (an iteration of a live app): reuse it and update files in place.
  if (!create.ok && create.status !== 422) throw new Error(`GitHub repo creation failed: ${create.status}`);
  const html_url = create.ok ? ((await create.json()) as { html_url: string }).html_url : `https://github.com/${owner}/${slug}`;

  for (const [path, content] of Object.entries(files)) {
    // Defense in depth: the reviewer already rejects these, but never trust model-supplied paths at the API boundary.
    if (!isSafePath(path)) throw new Error(`Refusing to write unsafe path: ${path}`);
    const url = `https://api.github.com/repos/${owner}/${slug}/contents/${path.split("/").map(encodeURIComponent).join("/")}`;
    const existing = await fetch(url, { headers });
    const sha = existing.ok ? ((await existing.json()) as { sha?: string }).sha : undefined;
    const res = await fetch(url, {
      method: "PUT",
      headers,
      body: JSON.stringify({ message: `${sha ? "Update" : "Add"} ${path}`, content: Buffer.from(content).toString("base64"), ...(sha ? { sha } : {}) }),
    });
    if (!res.ok) throw new Error(`GitHub write failed for ${path}: ${res.status}`);
  }
  return { url: html_url, mocked: false };
}

export async function createVercelProject(slug: string, repoUrl: string) {
  const token = process.env.VERCEL_TOKEN;
  if (!token) return { id: `prj_${hex(6)}`, url: `https://${slug}.vercel.app`, mocked: true };

  const team = process.env.VERCEL_TEAM_ID ? `?teamId=${process.env.VERCEL_TEAM_ID}` : "";
  const res = await fetch(`https://api.vercel.com/v10/projects${team}`, {
    method: "POST",
    headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      name: slug,
      framework: "nextjs",
      gitRepository: { type: "github", repo: repoUrl.replace("https://github.com/", "") },
    }),
  });
  if (res.status === 409) return { id: `existing-${slug}`, url: `https://${slug}.vercel.app`, mocked: false }; // iteration: project exists
  if (!res.ok) throw new Error(`Vercel project creation failed: ${res.status}`);
  const p = (await res.json()) as { id: string };
  return { id: p.id, url: `https://${slug}.vercel.app`, mocked: false };
}

/**
 * One wallet per app. In production, create via Coinbase CDP / Privy server wallets;
 * only the provider reference is stored — private keys never touch this database.
 */
export async function createAppWallet() {
  if (process.env.CDP_API_KEY_ID && process.env.CDP_API_KEY_SECRET) {
    // Plug in @coinbase/cdp-sdk: const account = await cdp.evm.createAccount(); return { address: account.address, providerRef: account.address }
  }
  const address = "0x" + hex(20);
  return { address, providerRef: `mock-wallet-${hex(6)}`, mocked: true };
}

export async function launchToken(symbol: string, name: string, creatorAddress: string) {
  if (process.env.CLANKER_API_KEY) {
    // Plug in the Clanker deploy endpoint here; creator receives 60% of trading fees (6000 bps).
  }
  return { contract: "0x" + hex(20), symbol, name, creatorAddress, creatorShareBps: 6000, mocked: true };
}

export function farcasterManifest(name: string, liveUrl: string) {
  const domain = new URL(liveUrl).host;
  return {
    accountAssociation: { header: "", payload: "", signature: "" }, // sign with the owner's Farcaster custody key
    miniapp: {
      version: "1",
      name,
      homeUrl: liveUrl,
      iconUrl: `${liveUrl}/icon.png`,
      splashImageUrl: `${liveUrl}/splash.png`,
      splashBackgroundColor: "#0b1f17",
      canonicalDomain: domain,
    },
  };
}
