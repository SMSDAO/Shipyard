import { randomBytes } from "node:crypto";

const API = "https://api.telegram.org";

async function call<T>(token: string, method: string, body: object): Promise<T> {
  const res = await fetch(`${API}/bot${token}/${method}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
    signal: AbortSignal.timeout(8000),
  });
  const data = (await res.json()) as { ok: boolean; result: T; description?: string };
  if (!data.ok) throw Object.assign(new Error(`Telegram: ${data.description ?? "request failed"}`), { status: 400 });
  return data.result;
}

/** Validates the bot token, points the bot's webhook at us with a secret header, returns the bot username. */
export async function connectBot(token: string, webhookUrl: string) {
  const me = await call<{ username: string }>(token, "getMe", {});
  const secret = randomBytes(24).toString("base64url");
  await call(token, "setWebhook", { url: webhookUrl, secret_token: secret, allowed_updates: ["message"] });
  return { username: me.username, secret };
}

export async function disconnectBot(token: string) {
  await call(token, "deleteWebhook", {}).catch(() => {});
}

export async function replyWithApp(token: string, chatId: number, appName: string, url: string) {
  await call(token, "sendMessage", {
    chat_id: chatId,
    text: `Welcome to ${appName}`,
    reply_markup: { inline_keyboard: [[{ text: `Open ${appName}`, web_app: { url } }]] },
  });
}
