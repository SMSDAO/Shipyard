import { db } from "./db";

/** Append-only record of privileged actions. Pass orgId so org admins can export their own trail. */
export async function audit(
  actorId: string | null,
  action: string,
  target?: string,
  meta?: object,
  orgId?: string | null,
) {
  await db.auditLog.create({
    data: { actorId, action, target, meta: meta as object | undefined, orgId: orgId ?? undefined },
  });
}
