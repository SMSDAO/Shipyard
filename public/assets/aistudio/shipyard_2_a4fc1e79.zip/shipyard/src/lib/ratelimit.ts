/**
 * Fixed-window rate limiter.
 * - With UPSTASH_REDIS_REST_URL/TOKEN set: shared across instances (INCR + PEXPIRE).
 * - Otherwise: in-memory sliding window (single instance / dev / tests).
 * If Redis is unreachable we fail open and log, so an outage doesn't take the API down.
 */
const hits = new Map<string, number[]>();

function tooMany(): never {
  throw Object.assign(new Error("Rate limit exceeded"), { status: 429 });
}

export async function rateLimit(key: string, limit: number, windowMs: number): Promise<void> {
  const url = process.env.UPSTASH_REDIS_REST_URL;
  const token = process.env.UPSTASH_REDIS_REST_TOKEN;

  if (url && token) {
    try {
      const k = `rl:${key}:${Math.floor(Date.now() / windowMs)}`;
      const res = await fetch(`${url}/pipeline`, {
        method: "POST",
        headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
        body: JSON.stringify([["INCR", k], ["PEXPIRE", k, String(windowMs)]]),
        signal: AbortSignal.timeout(1500),
      });
      if (!res.ok) throw new Error(`redis ${res.status}`);
      const [first] = (await res.json()) as Array<{ result: number }>;
      if (first.result > limit) tooMany();
      return;
    } catch (e) {
      if ((e as { status?: number }).status === 429) throw e;
      console.error(JSON.stringify({ level: "error", msg: "ratelimit redis failure, failing open", err: String(e) }));
      return;
    }
  }

  const now = Date.now();
  const recent = (hits.get(key) ?? []).filter((t) => now - t < windowMs);
  if (recent.length >= limit) {
    hits.set(key, recent);
    tooMany();
  }
  recent.push(now);
  hits.set(key, recent);
}

/** Test helper. */
export function _resetRateLimits() {
  hits.clear();
}

/** Strip control characters and cap length on natural-language input. */
export function sanitizePrompt(input: string, max = 65_000) {
  // eslint-disable-next-line no-control-regex
  return input.replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g, "").trim().slice(0, max);
}

export function clientIp(h: Headers) {
  return h.get("x-forwarded-for")?.split(",")[0]?.trim() ?? h.get("x-real-ip") ?? "unknown";
}
