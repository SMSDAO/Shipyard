"use client";

import { use, useState } from "react";
import { useRouter } from "next/navigation";
import { toast } from "sonner";

export default function Invite({ params }: { params: Promise<{ token: string }> }) {
  const { token } = use(params);
  const router = useRouter();
  const [busy, setBusy] = useState(false);

  async function accept() {
    setBusy(true);
    const res = await fetch("/api/invitations/accept", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ token }) });
    if (res.status === 401) return router.push(`/login?next=${encodeURIComponent(`/invite/${token}`)}`);
    const d = await res.json();
    setBusy(false);
    if (!res.ok) return toast.error(d.error ?? "Could not accept invitation");
    toast.success("You've joined the workspace");
    router.push("/org");
  }

  return (
    <div className="card mx-auto max-w-sm space-y-3 text-center">
      <h1 className="text-lg font-semibold">Workspace invitation</h1>
      <p className="text-sm text-zinc-500">Accept to join this workspace on Shipyard.</p>
      <button className="btn w-full" disabled={busy} onClick={accept}>{busy ? "Joining…" : "Accept invitation"}</button>
    </div>
  );
}
