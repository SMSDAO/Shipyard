"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { toast } from "sonner";

const CHIPS: Record<string, string> = {
  "Arcade game": "A retro arcade game with onchain high scores and weekly prize pools for the top players.",
  "Tipping bot": "A tipping bot that lets fans send micro-tips to their favorite creators from inside chat.",
  "Meme maker": "A meme maker that turns a prompt into a meme and mints it with creator royalties.",
};

export default function Home() {
  const router = useRouter();
  const [name, setName] = useState("");
  const [idea, setIdea] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    try {
      const d = sessionStorage.getItem("sy_draft");
      if (d) { const v = JSON.parse(d) as { name: string; idea: string }; setName(v.name); setIdea(v.idea); sessionStorage.removeItem("sy_draft"); }
    } catch { /* ignore */ }
  }, []);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    try {
      const res = await fetch("/api/apps", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ name, idea }) });
      if (res.status === 401) {
        try { sessionStorage.setItem("sy_draft", JSON.stringify({ name, idea })); } catch { /* storage unavailable */ }
        router.push("/login?next=/");
        return;
      }
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Could not create app");
      router.push(`/apps/${data.app.id}?start=1`);
    } catch (err) {
      toast.error((err as Error).message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <section className="mx-auto max-w-xl space-y-6 py-6 text-center">
      <h1 className="text-3xl font-bold tracking-tight sm:text-4xl">Describe it. <span className="text-brand-600">Ship it.</span></h1>
      <p className="text-zinc-500">An AI agent builds, deploys, and funds your onchain miniapp.</p>
      <form onSubmit={submit} className="card space-y-3 text-left">
        <label className="block text-sm font-medium">App name
          <input className="input mt-1" maxLength={30} required value={name} onChange={(e) => setName(e.target.value)} placeholder="Pixel Arcade" />
        </label>
        <label className="block text-sm font-medium">Your idea
          <textarea className="input mt-1 min-h-32" minLength={20} maxLength={65000} required value={idea} onChange={(e) => setIdea(e.target.value)} placeholder="Describe what it does, in any language…" />
        </label>
        <div className="flex flex-wrap gap-2">
          {Object.entries(CHIPS).map(([label, text]) => (
            <button type="button" key={label} className="chip" onClick={() => { setIdea(text); if (!name) setName(label); }}>{label}</button>
          ))}
        </div>
        <button className="btn w-full" disabled={busy || name.length < 1 || idea.length < 20}>{busy ? "Creating…" : "Create app"}</button>
      </form>
    </section>
  );
}
