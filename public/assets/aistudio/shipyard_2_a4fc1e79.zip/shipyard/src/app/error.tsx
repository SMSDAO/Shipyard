"use client";

export default function Error({ error, reset }: { error: Error; reset: () => void }) {
  return (
    <div className="card mx-auto max-w-md text-center">
      <h2 className="text-lg font-semibold">Something went wrong</h2>
      <p className="my-2 text-sm text-zinc-500">{error.message}</p>
      <button className="btn" onClick={reset}>Try again</button>
    </div>
  );
}
