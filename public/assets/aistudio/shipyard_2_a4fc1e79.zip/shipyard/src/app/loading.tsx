export default function Loading() {
  return (
    <div className="space-y-3" role="status" aria-label="Loading">
      <div className="shimmer h-24" />
      <div className="grid gap-3 sm:grid-cols-2">
        <div className="shimmer h-28" />
        <div className="shimmer h-28" />
      </div>
    </div>
  );
}
