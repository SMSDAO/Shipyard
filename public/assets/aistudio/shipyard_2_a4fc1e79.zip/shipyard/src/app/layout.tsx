import type { Metadata, Viewport } from "next";
import Link from "next/link";
import { Toaster } from "sonner";
import "./globals.css";
import Providers from "@/components/Providers";

export const metadata: Metadata = {
  title: "Shipyard — idea to onchain miniapp",
  description: "Describe an idea. An AI agent builds, deploys, and funds your onchain miniapp.",
  manifest: "/manifest.webmanifest",
  icons: { icon: "/favicon.svg" },
  openGraph: { title: "Shipyard", description: "Describe it. Ship it.", images: ["/og.svg"] },
};
export const viewport: Viewport = { themeColor: "#059669", width: "device-width", initialScale: 1 };

const nav = [
  ["/", "Create"], ["/apps", "My Apps"], ["/explore", "Explore"], ["/tokens", "Tokens"], ["/org", "Team"],
] as const;

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body>
        <div className="aurora" aria-hidden="true"><i /></div>
        <header className="glass sticky top-0 z-10 rounded-none border-x-0 border-t-0">
          <nav className="mx-auto flex max-w-5xl items-center gap-4 overflow-x-auto px-4 py-3 text-sm">
            <Link href="/" className="flex items-center gap-2 font-semibold text-brand-600"><img src="/icon.svg" alt="" width={24} height={24} />Shipyard</Link>
            {nav.map(([href, label]) => (
              <Link key={href} href={href} className="whitespace-nowrap opacity-70 transition hover:text-brand-600 hover:opacity-100">{label}</Link>
            ))}
            <Link href="/admin" className="ml-auto opacity-50 transition hover:text-brand-600 hover:opacity-100">Admin</Link>
          </nav>
        </header>
        <Providers><main className="mx-auto max-w-5xl px-4 py-6">{children}</main></Providers>
        <Toaster richColors position="top-center" />
      </body>
    </html>
  );
}
