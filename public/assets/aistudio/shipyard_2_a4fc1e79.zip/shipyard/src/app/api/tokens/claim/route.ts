import { z } from "zod";
import { db } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { handle } from "@/lib/http";
import { assertCan } from "@/lib/rbac";
import { audit } from "@/lib/audit";
import { emitForApp } from "@/lib/webhooks";

export const POST = (req: Request) =>
  handle(async () => {
    const user = await requireUser();
    const { appId } = z.object({ appId: z.string() }).parse(await req.json());
    const token = await db.token.findUnique({ where: { appId }, include: { app: true } });
    if (!token) throw Object.assign(new Error("Not found"), { status: 404 });
    assertCan(user, "claim_fees", { isAppOwner: token.app.ownerId === user.id });

    const claimable = (BigInt(token.feesAccruedWei) * BigInt(token.creatorShareBps)) / 10_000n - BigInt(token.feesClaimedWei);
    if (claimable <= 0n) throw Object.assign(new Error("Nothing to claim"), { status: 400 });

    const claim = await db.$transaction(async (tx) => {
      const res = await tx.token.updateMany({
        where: { id: token.id, feesClaimedWei: token.feesClaimedWei },
        data: { feesClaimedWei: (BigInt(token.feesClaimedWei) + claimable).toString() },
      });
      if (res.count === 0) throw Object.assign(new Error("Concurrent claim, retry"), { status: 409 });
      return tx.feeClaim.create({ data: { tokenId: token.id, amountWei: claimable.toString() } });
    });
    await audit(user.id, "fees.claim", appId, { amountWei: claimable.toString() }, token.app.orgId);
    await emitForApp(appId, "fees.claimed", { amountWei: claimable.toString() });
    return { claim };
  });
