import { z } from "zod";
import { db } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { handle, httpError } from "@/lib/http";
import { audit } from "@/lib/audit";
import { rateLimit } from "@/lib/ratelimit";

const Create = z.object({
  name: z.string().trim().min(2).max(60),
  slug: z.string().trim().toLowerCase().regex(/^[a-z0-9](?:[a-z0-9-]{1,38}[a-z0-9])$/, "3-40 chars: a-z, 0-9, hyphens"),
});

export const GET = () =>
  handle(async () => {
    const user = await requireUser();
    const memberships = await db.membership.findMany({ where: { userId: user.id }, include: { org: true } });
    return { orgs: memberships.map((m) => ({ id: m.org.id, name: m.org.name, slug: m.org.slug, role: m.role })) };
  });

export const POST = (req: Request) =>
  handle(async () => {
    const user = await requireUser();
    await rateLimit(`org-create:${user.id}`, 5, 24 * 60 * 60_000);
    const body = Create.parse(await req.json());
    if (await db.organization.findUnique({ where: { slug: body.slug } })) throw httpError(409, "Slug already taken");

    const org = await db.organization.create({
      data: { ...body, memberships: { create: { userId: user.id, role: "OWNER" } } },
    });
    await audit(user.id, "org.create", org.id, { slug: org.slug }, org.id);
    return { org };
  });
