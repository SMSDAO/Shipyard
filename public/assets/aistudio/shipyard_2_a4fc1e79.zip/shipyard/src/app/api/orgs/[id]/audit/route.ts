import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { handle } from "@/lib/http";
import { requireOrg } from "@/lib/org";
import { audit } from "@/lib/audit";

/** CSV cells starting with = + - @ are prefixed with ' so spreadsheets never evaluate them as formulas. */
function cell(v: unknown) {
  let s = v == null ? "" : typeof v === "string" ? v : JSON.stringify(v);
  if (/^[=+\-@\t\r]/.test(s)) s = `'${s}`;
  return `"${s.replace(/"/g, '""')}"`;
}

export async function GET(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const url = new URL(req.url);
  const { id } = await params;

  const result = await handle(async () => {
    const user = await requireUser();
    await requireOrg(user, id, "manage_team");
    const from = url.searchParams.get("from");
    const to = url.searchParams.get("to");
    const logs = await db.auditLog.findMany({
      where: { orgId: id, createdAt: { gte: from ? new Date(from) : undefined, lte: to ? new Date(to) : undefined } },
      orderBy: { createdAt: "desc" },
      take: Math.min(Number(url.searchParams.get("limit") ?? 200), 10_000),
      include: { actor: { select: { email: true, handle: true } } },
    });
    if (url.searchParams.get("format") === "csv") {
      await audit(user.id, "audit.export", id, undefined, id);
      return { csv: logs };
    }
    return { logs };
  });

  // handle() returns JSON; convert the csv marker into a file response.
  if (url.searchParams.get("format") === "csv" && result.status === 200) {
    const { csv } = (await result.json()) as { csv: Array<{ createdAt: string; action: string; target: string | null; meta: unknown; actor: { email: string | null; handle: string | null } | null }> };
    const rows = [["time", "actor", "action", "target", "meta"].join(",")].concat(
      csv.map((l) => [l.createdAt, l.actor?.email ?? l.actor?.handle ?? "", l.action, l.target, l.meta].map(cell).join(",")),
    );
    return new NextResponse(rows.join("\r\n"), {
      headers: { "Content-Type": "text/csv; charset=utf-8", "Content-Disposition": `attachment; filename="audit-${id}.csv"` },
    });
  }
  return result;
}
