import { z } from "zod";
import { db } from "@/lib/db";
import { hashKey, requireUser } from "@/lib/auth";
import { handle, httpError } from "@/lib/http";
import { audit } from "@/lib/audit";
import { emit } from "@/lib/webhooks";
import { rateLimit } from "@/lib/ratelimit";

/**
 * The invite token is a bearer secret (192 bits, single use, 7-day expiry). If the accepting
 * account has a verified email on file it must match the invited address.
 */
export const POST = (req: Request) =>
  handle(async () => {
    const user = await requireUser();
    await rateLimit(`invite-accept:${user.id}`, 10, 60 * 60_000);
    const { token } = z.object({ token: z.string().min(16).max(128) }).parse(await req.json());

    const inv = await db.invitation.findUnique({ where: { tokenHash: hashKey(token) } });
    if (!inv || inv.acceptedAt || inv.expiresAt < new Date()) throw httpError(400, "Invitation is invalid or expired");
    if (user.email && user.email.toLowerCase() !== inv.email) throw httpError(403, "This invitation was sent to a different email address");

    await db.$transaction(async (tx) => {
      const claimed = await tx.invitation.updateMany({ where: { id: inv.id, acceptedAt: null }, data: { acceptedAt: new Date() } });
      if (claimed.count === 0) throw httpError(409, "Invitation already used");
      await tx.membership.upsert({
        where: { userId_orgId: { userId: user.id, orgId: inv.orgId } },
        update: {},
        create: { userId: user.id, orgId: inv.orgId, role: inv.role },
      });
    });
    await audit(user.id, "member.join", user.id, { role: inv.role }, inv.orgId);
    await emit(inv.orgId, "member.added", { userId: user.id, role: inv.role });
    return { orgId: inv.orgId };
  });
