import { createHmac, timingSafeEqual } from "node:crypto";
import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { grantCredits } from "@/lib/credits";

/** Verifies Stripe's signature manually (HMAC-SHA256 over `${t}.${rawBody}`, 5 min tolerance). */
function verify(raw: string, header: string | null, secret: string) {
  if (!header) return false;
  const parts = Object.fromEntries(header.split(",").map((p) => p.split("=") as [string, string]));
  const t = parts.t;
  const sig = parts.v1;
  if (!t || !sig || Math.abs(Date.now() / 1000 - Number(t)) > 300) return false;
  const expected = createHmac("sha256", secret).update(`${t}.${raw}`).digest("hex");
  const a = Buffer.from(expected);
  const b = Buffer.from(sig);
  return a.length === b.length && timingSafeEqual(a, b);
}

export async function POST(req: Request) {
  const secret = process.env.STRIPE_WEBHOOK_SECRET;
  if (!secret) return NextResponse.json({ error: "Not configured" }, { status: 400 });

  const raw = await req.text();
  if (!verify(raw, req.headers.get("stripe-signature"), secret)) {
    return NextResponse.json({ error: "Bad signature" }, { status: 400 });
  }

  const event = JSON.parse(raw) as {
    type: string;
    data: { object: { id: string; metadata?: { userId?: string; credits?: string } } };
  };

  if (event.type === "checkout.session.completed") {
    const s = event.data.object;
    const userId = s.metadata?.userId;
    const credits = Number(s.metadata?.credits);
    if (userId && Number.isInteger(credits) && credits > 0) {
      const reason = `Stripe checkout ${s.id}`;
      // Idempotent: Stripe retries webhooks, so never grant the same session twice.
      const done = await db.creditTransaction.findFirst({ where: { userId, reason } });
      if (!done) await grantCredits(userId, credits, reason, "PURCHASE");
    }
  }
  return NextResponse.json({ received: true });
}
