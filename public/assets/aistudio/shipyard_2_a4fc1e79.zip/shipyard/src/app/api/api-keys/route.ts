import { z } from "zod";
import { db } from "@/lib/db";
import { generateApiKey, requireUser } from "@/lib/auth";
import { handle, httpError } from "@/lib/http";
import { audit } from "@/lib/audit";

const Create = z.object({
  name: z.string().trim().min(1).max(60),
  readOnly: z.boolean().default(false),
  expiresInDays: z.number().int().min(1).max(365).optional(),
});

export const GET = () =>
  handle(async () => {
    const user = await requireUser();
    const keys = await db.apiKey.findMany({
      where: { userId: user.id, revokedAt: null },
      select: { id: true, name: true, prefix: true, readOnly: true, lastUsedAt: true, expiresAt: true, createdAt: true },
      orderBy: { createdAt: "desc" },
    });
    return { keys };
  });

export const POST = (req: Request) =>
  handle(async () => {
    const user = await requireUser();
    // API keys can't mint more API keys: a leaked key must not be able to persist itself.
    const viaKey = (req.headers.get("authorization") ?? "").startsWith("Bearer sk_");
    if (viaKey) throw httpError(403, "Create API keys from a signed-in session");

    const body = Create.parse(await req.json());
    const active = await db.apiKey.count({ where: { userId: user.id, revokedAt: null } });
    if (active >= 20) throw httpError(400, "Key limit reached (20). Revoke an unused key first.");

    const { key, prefix, hash } = generateApiKey();
    const row = await db.apiKey.create({
      data: {
        userId: user.id, name: body.name, prefix, hash, readOnly: body.readOnly,
        expiresAt: body.expiresInDays ? new Date(Date.now() + body.expiresInDays * 864e5) : null,
      },
    });
    await audit(user.id, "apikey.create", row.id, { name: body.name, readOnly: body.readOnly });
    // The plaintext key is returned exactly once.
    return { id: row.id, key, prefix };
  });
