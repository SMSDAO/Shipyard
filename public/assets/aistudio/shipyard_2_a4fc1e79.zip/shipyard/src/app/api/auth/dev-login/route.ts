import { z } from "zod";
import { db } from "@/lib/db";
import { createSession, clearSession } from "@/lib/auth";
import { handle } from "@/lib/http";

/**
 * Dev/fallback sign-in by email. In production, replace with Privy:
 * verify the Privy access token server-side, upsert the user by DID, then call createSession().
 * Disabled in production unless ALLOW_DEV_LOGIN=true.
 */
export const POST = (req: Request) =>
  handle(async () => {
    if (process.env.NODE_ENV === "production" && process.env.ALLOW_DEV_LOGIN !== "true") {
      throw Object.assign(new Error("Disabled"), { status: 403 });
    }
    const { email } = z.object({ email: z.string().email() }).parse(await req.json());
    const user = await db.user.upsert({
      where: { email },
      update: {},
      create: { email, handle: email.split("@")[0], credits: 200 },
    });
    await createSession(user.id);
    return { ok: true };
  });

export const DELETE = () => handle(async () => { await clearSession(); return { ok: true }; });
