import { z } from "zod";
import { db } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { handle } from "@/lib/http";
import { grantCredits } from "@/lib/credits";

export const GET = () =>
  handle(async () => {
    const user = await requireUser();
    const txs = await db.creditTransaction.findMany({ where: { userId: user.id }, orderBy: { createdAt: "desc" }, take: 50 });
    return { balance: user.credits, transactions: txs };
  });

/**
 * Top-up. With STRIPE_SECRET_KEY set this creates a Checkout session; credits are granted
 * by the Stripe webhook after payment. Without it (dev), credits are granted immediately.
 */
export const POST = (req: Request) =>
  handle(async () => {
    const user = await requireUser();
    const { pack } = z.object({ pack: z.enum(["100", "500", "2000"]) }).parse(await req.json());
    const credits = Number(pack);

    if (process.env.STRIPE_SECRET_KEY) {
      const params = new URLSearchParams({
        mode: "payment",
        success_url: `${process.env.NEXT_PUBLIC_APP_URL}/apps?topup=success`,
        cancel_url: `${process.env.NEXT_PUBLIC_APP_URL}/apps`,
        "line_items[0][price_data][currency]": "usd",
        "line_items[0][price_data][unit_amount]": String(credits * 2),
        "line_items[0][price_data][product_data][name]": `${credits} credits`,
        "line_items[0][quantity]": "1",
        "metadata[userId]": user.id,
        "metadata[credits]": String(credits),
      });
      const res = await fetch("https://api.stripe.com/v1/checkout/sessions", {
        method: "POST",
        headers: { Authorization: `Bearer ${process.env.STRIPE_SECRET_KEY}`, "Content-Type": "application/x-www-form-urlencoded" },
        body: params,
      });
      if (!res.ok) throw new Error("Stripe error");
      const s = (await res.json()) as { url: string };
      return { checkoutUrl: s.url };
    }

    await grantCredits(user.id, credits, `Dev top-up (${credits})`, "PURCHASE");
    return { granted: credits };
  });
