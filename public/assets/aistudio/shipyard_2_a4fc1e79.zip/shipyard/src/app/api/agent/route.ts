import { z } from "zod";
import { db } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { handle } from "@/lib/http";
import { assertCan } from "@/lib/rbac";
import { rateLimit, sanitizePrompt } from "@/lib/ratelimit";
import { runAgentTurn } from "@/lib/agent/loop";

export const maxDuration = 300;

const Body = z.object({ appId: z.string(), message: z.string().min(1).max(65_000) });

export const POST = (req: Request) =>
  handle(async () => {
    const user = await requireUser();
    await rateLimit(`agent:${user.id}`, 30, 60 * 60_000);
    const { appId, message } = Body.parse(await req.json());

    const app = await db.app.findUnique({ where: { id: appId } });
    if (!app) throw Object.assign(new Error("Not found"), { status: 404 });
    const collab = await db.appCollaborator.findUnique({ where: { appId_userId: { appId, userId: user.id } } });
    assertCan(user, "iterate_app", { isAppOwner: app.ownerId === user.id, orgRole: collab?.role });

    return runAgentTurn({ appId, userId: user.id, userMessage: sanitizePrompt(message) });
  });

export const GET = (req: Request) =>
  handle(async () => {
    const user = await requireUser();
    const appId = new URL(req.url).searchParams.get("appId");
    if (!appId) throw Object.assign(new Error("appId required"), { status: 400 });
    const app = await db.app.findFirst({ where: { id: appId, ownerId: user.id } });
    if (!app) throw Object.assign(new Error("Not found"), { status: 404 });
    const convo = await db.conversation.findUnique({
      where: { appId },
      include: { messages: { where: { role: { in: ["USER", "ASSISTANT"] } }, orderBy: { createdAt: "asc" } } },
    });
    const build = await db.buildJob.findFirst({ where: { appId }, orderBy: { createdAt: "desc" } });
    return { messages: convo?.messages ?? [], status: app.status, step: build?.step ?? null };
  });
