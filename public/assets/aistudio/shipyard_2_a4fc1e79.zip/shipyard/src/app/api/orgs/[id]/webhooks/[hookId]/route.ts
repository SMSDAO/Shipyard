import { db } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { handle, httpError } from "@/lib/http";
import { requireOrg } from "@/lib/org";
import { audit } from "@/lib/audit";

export const DELETE = (_req: Request, { params }: { params: Promise<{ id: string; hookId: string }> }) =>
  handle(async () => {
    const { id, hookId } = await params;
    const user = await requireUser();
    await requireOrg(user, id, "manage_team");
    const res = await db.webhookEndpoint.deleteMany({ where: { id: hookId, orgId: id } });
    if (res.count === 0) throw httpError(404, "Endpoint not found");
    await audit(user.id, "webhook.delete", hookId, undefined, id);
    return { ok: true };
  });
