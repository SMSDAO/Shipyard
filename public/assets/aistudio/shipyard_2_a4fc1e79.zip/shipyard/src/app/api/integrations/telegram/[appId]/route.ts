import { timingSafeEqual } from "node:crypto";
import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { decrypt } from "@/lib/crypto";
import { log } from "@/lib/http";
import { replyWithApp } from "@/lib/services/telegram";

/** Telegram webhook receiver. Authenticated by the per-app secret token Telegram echoes in a header. */
export async function POST(req: Request, { params }: { params: Promise<{ appId: string }> }) {
  const { appId } = await params;
  const integ = await db.platformIntegration.findUnique({
    where: { appId_kind: { appId, kind: "TELEGRAM" } },
    include: { app: true },
  });
  const cfg = integ?.config as { botTokenEnc?: string; secretEnc?: string } | null;
  if (!integ?.enabled || !cfg?.botTokenEnc || !cfg.secretEnc) return NextResponse.json({ ok: true }); // don't reveal state

  const given = Buffer.from(req.headers.get("x-telegram-bot-api-secret-token") ?? "");
  const want = Buffer.from(decrypt(cfg.secretEnc));
  if (given.length !== want.length || !timingSafeEqual(given, want)) return NextResponse.json({ error: "Forbidden" }, { status: 403 });

  const update = (await req.json()) as { message?: { chat?: { id: number }; text?: string } };
  const chatId = update.message?.chat?.id;
  if (chatId && update.message?.text?.startsWith("/start") && integ.app.liveUrl) {
    await replyWithApp(decrypt(cfg.botTokenEnc), chatId, integ.app.name, integ.app.liveUrl).catch((e) =>
      log("warn", "telegram reply failed", { appId, err: String(e) }),
    );
  }
  return NextResponse.json({ ok: true });
}
