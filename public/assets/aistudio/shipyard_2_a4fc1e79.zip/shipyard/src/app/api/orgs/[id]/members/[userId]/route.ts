import { z } from "zod";
import { db } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { handle, httpError } from "@/lib/http";
import { assertCanAssign, assertNotLastOwner, requireOrg } from "@/lib/org";
import { audit } from "@/lib/audit";
import { emit } from "@/lib/webhooks";

type Ctx = { params: Promise<{ id: string; userId: string }> };

export const PATCH = (req: Request, { params }: Ctx) =>
  handle(async () => {
    const { id, userId } = await params;
    const actor = await requireUser();
    const mine = await requireOrg(actor, id, "manage_team");
    const { role } = z.object({ role: z.enum(["OWNER", "ADMIN", "BUILDER", "VIEWER"]) }).parse(await req.json());

    const target = await db.membership.findUnique({ where: { userId_orgId: { userId, orgId: id } } });
    if (!target) throw httpError(404, "Member not found");
    assertCanAssign(mine?.role, role, target.role);
    if (target.role === "OWNER" && role !== "OWNER") await assertNotLastOwner(id, userId);

    const updated = await db.membership.update({ where: { id: target.id }, data: { role } });
    await audit(actor.id, "member.role_change", userId, { from: target.role, to: role }, id);
    return { member: { userId, role: updated.role } };
  });

export const DELETE = (_req: Request, { params }: Ctx) =>
  handle(async () => {
    const { id, userId } = await params;
    const actor = await requireUser();
    // Members may always remove themselves; removing others needs manage_team.
    const mine = userId === actor.id ? await requireOrg(actor, id, "view_analytics") : await requireOrg(actor, id, "manage_team");

    const target = await db.membership.findUnique({ where: { userId_orgId: { userId, orgId: id } } });
    if (!target) throw httpError(404, "Member not found");
    if (userId !== actor.id) assertCanAssign(mine?.role, target.role, target.role);
    if (target.role === "OWNER") await assertNotLastOwner(id, userId);

    await db.membership.delete({ where: { id: target.id } });
    await audit(actor.id, "member.remove", userId, undefined, id);
    await emit(id, "member.removed", { userId });
    return { ok: true };
  });
