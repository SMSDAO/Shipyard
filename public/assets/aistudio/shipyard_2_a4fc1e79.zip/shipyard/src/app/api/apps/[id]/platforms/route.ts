import { z } from "zod";
import { db } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { handle, httpError } from "@/lib/http";
import { assertCan } from "@/lib/rbac";
import { audit } from "@/lib/audit";
import { encrypt, decrypt } from "@/lib/crypto";
import { connectBot, disconnectBot } from "@/lib/services/telegram";
import { farcasterManifest } from "@/lib/services/providers";

const Body = z.discriminatedUnion("kind", [
  z.object({ kind: z.literal("WEB"), enabled: z.boolean() }),
  z.object({ kind: z.literal("BASE"), enabled: z.boolean() }),
  z.object({ kind: z.literal("CELO"), enabled: z.boolean() }),
  z.object({ kind: z.literal("FARCASTER"), enabled: z.boolean() }),
  z.object({ kind: z.literal("WORLD"), enabled: z.boolean(), worldAppId: z.string().regex(/^app_[a-zA-Z0-9]{8,64}$/).optional() }),
  z.object({ kind: z.literal("TELEGRAM"), enabled: z.boolean(), botToken: z.string().regex(/^\d{6,12}:[A-Za-z0-9_-]{30,50}$/).optional() }),
]);

export const PATCH = (req: Request, { params }: { params: Promise<{ id: string }> }) =>
  handle(async () => {
    const { id } = await params;
    const user = await requireUser();
    const body = Body.parse(await req.json());

    const app = await db.app.findUnique({ where: { id } });
    if (!app) throw httpError(404, "Not found");
    const m = app.orgId ? await db.membership.findUnique({ where: { userId_orgId: { userId: user.id, orgId: app.orgId } } }) : null;
    assertCan(user, "manage_platforms", { isAppOwner: app.ownerId === user.id, orgRole: m?.role });

    const existing = await db.platformIntegration.findUnique({ where: { appId_kind: { appId: id, kind: body.kind } } });
    let config: Record<string, unknown> | undefined;

    if (body.enabled && !app.liveUrl && body.kind !== "WEB") throw httpError(400, "Deploy the app before enabling platforms");

    if (body.kind === "FARCASTER" && body.enabled) config = farcasterManifest(app.name, app.liveUrl!) as unknown as Record<string, unknown>;
    if (body.kind === "WORLD" && body.enabled) {
      const worldAppId = body.worldAppId ?? (existing?.config as { worldAppId?: string } | null)?.worldAppId;
      if (!worldAppId) throw httpError(400, "worldAppId is required (from the World developer portal)");
      config = { worldAppId };
    }
    if (body.kind === "TELEGRAM") {
      const prev = existing?.config as { botTokenEnc?: string } | null;
      if (body.enabled) {
        if (!body.botToken) throw httpError(400, "botToken is required");
        const base = process.env.NEXT_PUBLIC_APP_URL;
        if (!base) throw httpError(500, "NEXT_PUBLIC_APP_URL is not set");
        const bot = await connectBot(body.botToken, `${base}/api/integrations/telegram/${id}`);
        config = { botTokenEnc: encrypt(body.botToken), secretEnc: encrypt(bot.secret), username: bot.username };
      } else if (prev?.botTokenEnc) {
        await disconnectBot(decrypt(prev.botTokenEnc));
        config = {};
      }
    }

    const row = await db.platformIntegration.upsert({
      where: { appId_kind: { appId: id, kind: body.kind } },
      update: { enabled: body.enabled, ...(config ? { config: config as object } : {}) },
      create: { appId: id, kind: body.kind, enabled: body.enabled, config: (config ?? {}) as object },
    });
    await audit(user.id, "platform.toggle", id, { kind: body.kind, enabled: body.enabled }, app.orgId);
    return { platform: { kind: row.kind, enabled: row.enabled } }; // config (incl. encrypted secrets) is never returned
  });
