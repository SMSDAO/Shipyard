import { z } from "zod";
import { importSPKI, jwtVerify } from "jose";
import { db } from "@/lib/db";
import { createSession } from "@/lib/auth";
import { handle, httpError } from "@/lib/http";
import { audit } from "@/lib/audit";
import { clientIp, rateLimit } from "@/lib/ratelimit";

/**
 * Exchanges a Privy access token for a Shipyard session cookie.
 * Verifies the ES256 signature against PRIVY_VERIFICATION_KEY (PEM from the Privy dashboard),
 * issuer "privy.io", audience = your Privy app id. New users get SIGNUP_CREDITS.
 */
export const POST = (req: Request) =>
  handle(async () => {
    await rateLimit(`auth:${clientIp(req.headers)}`, 20, 10 * 60_000);
    const appId = process.env.NEXT_PUBLIC_PRIVY_APP_ID;
    const pem = process.env.PRIVY_VERIFICATION_KEY;
    if (!appId || !pem) throw httpError(503, "Privy is not configured");

    const { accessToken } = z.object({ accessToken: z.string().min(20) }).parse(await req.json());
    let privyId: string;
    try {
      const key = await importSPKI(pem.replace(/\\n/g, "\n"), "ES256");
      const { payload } = await jwtVerify(accessToken, key, { issuer: "privy.io", audience: appId });
      privyId = String(payload.sub);
    } catch {
      throw httpError(401, "Invalid access token");
    }

    const signup = Number(process.env.SIGNUP_CREDITS ?? 100);
    const existing = await db.user.findUnique({ where: { privyId } });
    const user = existing ?? (await db.user.create({ data: { privyId, credits: signup } }));
    if (!existing) await audit(user.id, "user.signup", user.id);
    await createSession(user.id);
    return { ok: true, userId: user.id };
  });
