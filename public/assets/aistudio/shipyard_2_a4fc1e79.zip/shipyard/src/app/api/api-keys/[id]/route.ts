import { db } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { handle, httpError } from "@/lib/http";
import { audit } from "@/lib/audit";

export const DELETE = (_req: Request, { params }: { params: Promise<{ id: string }> }) =>
  handle(async () => {
    const { id } = await params;
    const user = await requireUser();
    const res = await db.apiKey.updateMany({ where: { id, userId: user.id, revokedAt: null }, data: { revokedAt: new Date() } });
    if (res.count === 0) throw httpError(404, "Key not found");
    await audit(user.id, "apikey.revoke", id);
    return { ok: true };
  });
