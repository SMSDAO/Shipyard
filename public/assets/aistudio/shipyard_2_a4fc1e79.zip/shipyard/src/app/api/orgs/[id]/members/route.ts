import { db } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { handle } from "@/lib/http";
import { requireOrg } from "@/lib/org";

export const GET = (_req: Request, { params }: { params: Promise<{ id: string }> }) =>
  handle(async () => {
    const { id } = await params;
    const user = await requireUser();
    await requireOrg(user, id, "view_analytics");
    const members = await db.membership.findMany({ where: { orgId: id }, include: { user: true }, orderBy: { id: "asc" } });
    return {
      members: members.map((m) => ({ userId: m.userId, role: m.role, handle: m.user.handle, email: m.user.email })),
    };
  });
