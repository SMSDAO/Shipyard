import { z } from "zod";
import { db } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { handle } from "@/lib/http";
import { assertCan } from "@/lib/rbac";
import { audit } from "@/lib/audit";
import { rateLimit } from "@/lib/ratelimit";
import { emitForApp } from "@/lib/webhooks";

const Body = z.object({
  appId: z.string(),
  toAddress: z.string().regex(/^0x[a-fA-F0-9]{40}$/),
  amountWei: z.string().regex(/^\d+$/),
});

export const POST = (req: Request) =>
  handle(async () => {
    const user = await requireUser();
    await rateLimit(`withdraw:${user.id}`, 5, 60 * 60_000);
    const { appId, toAddress, amountWei } = Body.parse(await req.json());

    const app = await db.app.findUnique({ where: { id: appId }, include: { wallet: true } });
    if (!app?.wallet) throw Object.assign(new Error("Not found"), { status: 404 });
    const membership = app.orgId ? await db.membership.findUnique({ where: { userId_orgId: { userId: user.id, orgId: app.orgId } } }) : null;
    assertCan(user, "withdraw_wallet", { isAppOwner: app.ownerId === user.id, orgRole: membership?.role });

    const amount = BigInt(amountWei);
    const balance = BigInt(app.wallet.balanceWei);
    if (amount <= 0n || amount > balance) throw Object.assign(new Error("Invalid amount"), { status: 400 });

    // Signing happens at the wallet provider (CDP/Privy). Here we record the intent and new balance.
    const w = await db.$transaction(async (tx) => {
      const updated = await tx.appWallet.updateMany({
        where: { id: app.wallet!.id, balanceWei: app.wallet!.balanceWei },
        data: { balanceWei: (balance - amount).toString() },
      });
      if (updated.count === 0) throw Object.assign(new Error("Balance changed, retry"), { status: 409 });
      return tx.withdrawal.create({ data: { walletId: app.wallet!.id, toAddress, amountWei } });
    });
    await audit(user.id, "wallet.withdraw", appId, { toAddress, amountWei }, app.orgId);
    await emitForApp(appId, "wallet.withdrawal", { toAddress, amountWei });
    return { withdrawal: w };
  });
