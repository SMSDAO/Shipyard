import { randomBytes } from "node:crypto";
import { z } from "zod";
import { db } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { handle, httpError } from "@/lib/http";
import { requireOrg } from "@/lib/org";
import { encrypt } from "@/lib/crypto";
import { audit } from "@/lib/audit";
import { WEBHOOK_EVENTS, assertSafeUrl } from "@/lib/webhooks-core";

const Create = z.object({
  url: z.string().url().max(2048),
  events: z.array(z.enum(WEBHOOK_EVENTS)).min(1).max(WEBHOOK_EVENTS.length),
});

type Ctx = { params: Promise<{ id: string }> };

export const GET = (_req: Request, { params }: Ctx) =>
  handle(async () => {
    const { id } = await params;
    const user = await requireUser();
    await requireOrg(user, id, "manage_team");
    const endpoints = await db.webhookEndpoint.findMany({
      where: { orgId: id },
      select: {
        id: true, url: true, events: true, enabled: true, createdAt: true,
        deliveries: { orderBy: { createdAt: "desc" }, take: 5, select: { id: true, event: true, attempts: true, lastStatus: true, deliveredAt: true } },
      },
    });
    return { endpoints };
  });

export const POST = (req: Request, { params }: Ctx) =>
  handle(async () => {
    const { id } = await params;
    const user = await requireUser();
    await requireOrg(user, id, "manage_team");
    const body = Create.parse(await req.json());
    await assertSafeUrl(body.url);
    if ((await db.webhookEndpoint.count({ where: { orgId: id } })) >= 10) throw httpError(400, "Endpoint limit reached (10)");

    const secret = `whsec_${randomBytes(24).toString("base64url")}`;
    const ep = await db.webhookEndpoint.create({
      data: { orgId: id, url: body.url, events: body.events, secretEnc: encrypt(secret) },
    });
    await audit(user.id, "webhook.create", ep.id, { url: body.url, events: body.events }, id);
    // Signing secret is shown once; verify deliveries with the X-Shipyard-Signature header.
    return { id: ep.id, secret };
  });
