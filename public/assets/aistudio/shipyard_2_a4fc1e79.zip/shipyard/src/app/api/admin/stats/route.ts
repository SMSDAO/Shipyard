import { db } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { handle } from "@/lib/http";
import { assertCan } from "@/lib/rbac";

export const GET = () =>
  handle(async () => {
    const user = await requireUser();
    assertCan(user, "admin_panel");
    const [users, apps, live, failed, builds, spent, flags, logs] = await Promise.all([
      db.user.count(),
      db.app.count(),
      db.app.count({ where: { status: "LIVE" } }),
      db.buildJob.count({ where: { status: "FAILED" } }),
      db.buildJob.count(),
      db.creditTransaction.aggregate({ where: { type: "SPEND" }, _sum: { amount: true } }),
      db.featureFlag.findMany(),
      db.auditLog.findMany({ orderBy: { createdAt: "desc" }, take: 25 }),
    ]);
    return {
      users, apps, builds, failedBuilds: failed, liveBuilds: live,
      successRate: builds ? Math.round(((builds - failed) / builds) * 100) : null,
      creditsSpent: Math.abs(spent._sum.amount ?? 0),
      flags, logs,
    };
  });
