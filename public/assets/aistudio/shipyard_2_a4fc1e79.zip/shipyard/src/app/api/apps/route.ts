import { z } from "zod";
import { db } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { handle } from "@/lib/http";
import { can, assertCan } from "@/lib/rbac";
import { audit } from "@/lib/audit";
import { rateLimit, sanitizePrompt } from "@/lib/ratelimit";

const CreateApp = z.object({
  name: z.string().trim().min(1).max(30),
  idea: z.string().min(20).max(65_000),
  orgId: z.string().optional(),
});

const slugify = (s: string) => s.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 30);

export const GET = () =>
  handle(async () => {
    const user = await requireUser();
    const apps = await db.app.findMany({
      where: { OR: [{ ownerId: user.id }, { collaborators: { some: { userId: user.id } } }] },
      include: { wallet: true, token: true },
      orderBy: { updatedAt: "desc" },
    });
    return { apps };
  });

export const POST = (req: Request) =>
  handle(async () => {
    const user = await requireUser();
    await rateLimit(`create:${user.id}`, 10, 60 * 60_000);
    const body = CreateApp.parse(await req.json());

    let orgRole = null;
    if (body.orgId) {
      const m = await db.membership.findUnique({ where: { userId_orgId: { userId: user.id, orgId: body.orgId } } });
      orgRole = m?.role ?? null;
      if (!m) throw Object.assign(new Error("Not a member of that workspace"), { status: 403 });
    }
    assertCan(user, "create_app", { orgRole });

    const base = slugify(body.name) || "app";
    const slug = `${base}-${Math.random().toString(36).slice(2, 6)}`;
    const app = await db.app.create({
      data: { name: body.name, slug, idea: sanitizePrompt(body.idea), ownerId: user.id, orgId: body.orgId, status: "DRAFT" },
    });
    await audit(user.id, "app.create", app.id);
    return { app };
  });
