import { randomBytes } from "node:crypto";
import { z } from "zod";
import { db } from "@/lib/db";
import { hashKey, requireUser } from "@/lib/auth";
import { handle, httpError, log } from "@/lib/http";
import { assertCanAssign, requireOrg } from "@/lib/org";
import { audit } from "@/lib/audit";
import { rateLimit } from "@/lib/ratelimit";

const Body = z.object({
  email: z.string().email().max(254).transform((e) => e.toLowerCase()),
  role: z.enum(["ADMIN", "BUILDER", "VIEWER", "OWNER"]).default("VIEWER"),
});

const esc = (s: string) => s.replace(/[&<>"']/g, (c) => `&#${c.charCodeAt(0)};`);

async function sendEmail(to: string, orgName: string, url: string) {
  const key = process.env.RESEND_API_KEY;
  const from = process.env.EMAIL_FROM;
  if (!key || !from) return false;
  const res = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      from, to,
      subject: `You're invited to ${orgName} on Shipyard`,
      html: `<p>You've been invited to join <b>${esc(orgName)}</b> on Shipyard.</p><p><a href="${esc(url)}">Accept invitation</a> (expires in 7 days)</p>`,
    }),
  });
  if (!res.ok) log("warn", "invite email failed", { status: res.status });
  return res.ok;
}

export const GET = (_req: Request, { params }: { params: Promise<{ id: string }> }) =>
  handle(async () => {
    const { id } = await params;
    const user = await requireUser();
    await requireOrg(user, id, "manage_team");
    const invitations = await db.invitation.findMany({
      where: { orgId: id, acceptedAt: null, expiresAt: { gt: new Date() } },
      select: { id: true, email: true, role: true, expiresAt: true },
      orderBy: { createdAt: "desc" },
    });
    return { invitations };
  });

export const POST = (req: Request, { params }: { params: Promise<{ id: string }> }) =>
  handle(async () => {
    const { id } = await params;
    const user = await requireUser();
    const mine = await requireOrg(user, id, "manage_team");
    await rateLimit(`invite:${user.id}`, 30, 60 * 60_000);
    const { email, role } = Body.parse(await req.json());
    assertCanAssign(mine?.role, role);

    const existing = await db.membership.findFirst({ where: { orgId: id, user: { email } } });
    if (existing) throw httpError(409, "Already a member");

    const org = await db.organization.findUniqueOrThrow({ where: { id } });
    const token = randomBytes(24).toString("base64url");
    await db.invitation.create({
      data: { orgId: id, email, role, tokenHash: hashKey(token), invitedById: user.id, expiresAt: new Date(Date.now() + 7 * 864e5) },
    });
    const url = `${process.env.NEXT_PUBLIC_APP_URL ?? "http://localhost:3000"}/invite/${token}`;
    const emailed = await sendEmail(email, org.name, url);
    await audit(user.id, "member.invite", email, { role }, id);
    // If no email provider is configured, hand the link to the inviter to share manually.
    return { emailed, ...(emailed ? {} : { inviteUrl: url }) };
  });
