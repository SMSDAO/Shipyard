import { db } from "@/lib/db";
import { getUser } from "@/lib/auth";
import { handle } from "@/lib/http";
import { can } from "@/lib/rbac";

export const GET = (_req: Request, { params }: { params: Promise<{ id: string }> }) =>
  handle(async () => {
    const { id } = await params;
    const user = await getUser();
    const app = await db.app.findUnique({
      where: { id },
      include: { wallet: true, token: true, platforms: { select: { kind: true, enabled: true } }, builds: { orderBy: { createdAt: "desc" }, take: 10 } },
    });
    if (!app) throw Object.assign(new Error("Not found"), { status: 404 });

    const isOwner = user?.id === app.ownerId;
    const collab = user ? await db.appCollaborator.findUnique({ where: { appId_userId: { appId: id, userId: user.id } } }) : null;
    const allowed = app.isPublic || isOwner || !!collab || (user && can(user, "admin_panel"));
    if (!allowed) throw Object.assign(new Error("Not found"), { status: 404 });

    const privileged = isOwner || !!collab || (user ? can(user, "admin_panel") : false);
    return {
      app: { ...app, wallet: privileged ? app.wallet : null, builds: privileged ? app.builds : [] },
      permissions: user
        ? { iterate: can(user, "iterate_app", { isAppOwner: isOwner, orgRole: collab?.role }), claim: can(user, "claim_fees", { isAppOwner: isOwner, orgRole: collab?.role }) }
        : {},
    };
  });
