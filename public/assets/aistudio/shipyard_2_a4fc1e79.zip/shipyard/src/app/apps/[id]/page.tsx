import { notFound } from "next/navigation";
import { db } from "@/lib/db";
import { getUser } from "@/lib/auth";
import AgentChat from "@/components/AgentChat";
import AppActions from "@/components/AppActions";

export const dynamic = "force-dynamic";

export default async function AppDetail({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const user = await getUser();
  const app = await db.app.findUnique({
    where: { id },
    include: { wallet: true, token: true, platforms: true, builds: { orderBy: { createdAt: "desc" }, take: 5 } },
  });
  if (!app) notFound();
  const isOwner = user?.id === app.ownerId;
  if (!app.isPublic && !isOwner) notFound();

  const claimable = app.token
    ? (BigInt(app.token.feesAccruedWei) * BigInt(app.token.creatorShareBps)) / 10_000n - BigInt(app.token.feesClaimedWei)
    : 0n;
  const eth = (wei: bigint | string) => (Number(wei) / 1e18).toFixed(4);

  return (
    <div className="grid gap-4 lg:grid-cols-[1fr_360px]">
      <div className="space-y-4">
        <div className="card">
          <div className="flex items-center justify-between"><h1 className="text-xl font-semibold">{app.name}</h1><span className="chip">{app.status}</span></div>
          <p className="mt-1 text-sm text-zinc-500">{app.idea}</p>
          <div className="mt-3 flex flex-wrap gap-2 text-sm">
            {app.liveUrl && <a className="btn" href={app.liveUrl} target="_blank" rel="noreferrer">Open app</a>}
            {isOwner && app.repoUrl && <a className="btn-ghost" href={app.repoUrl} target="_blank" rel="noreferrer">Source code</a>}
          </div>
        </div>

        <div className="grid grid-cols-3 gap-3 text-center">
          <Stat label="Opens" value={app.opens} />
          <Stat label="Unique users" value={app.uniqueUsers} />
          <Stat label="Revenue" value={`$${(app.revenueCents / 100).toFixed(2)}`} />
        </div>

        {isOwner && app.wallet && (
          <div className="card space-y-2">
            <h2 className="font-semibold">App wallet</h2>
            <p className="break-all font-mono text-xs text-zinc-500">{app.wallet.address}</p>
            <p className="text-lg">{eth(app.wallet.balanceWei)} ETH</p>
            <AppActions appId={app.id} mode="withdraw" />
          </div>
        )}

        {isOwner && app.token && (
          <div className="card space-y-2">
            <h2 className="font-semibold">${app.token.symbol} — creator fees ({app.token.creatorShareBps / 100}% share)</h2>
            <p className="text-sm text-zinc-500">Claimable: {eth(claimable)} ETH</p>
            <AppActions appId={app.id} mode="claim" disabled={claimable <= 0n} />
          </div>
        )}

        <div className="card">
          <h2 className="mb-2 font-semibold">Platforms</h2>
          <div className="flex flex-wrap gap-2">
            {["WEB", "FARCASTER", "TELEGRAM", "WORLD", "CELO", "BASE"].map((k) => {
              const on = app.platforms.some((p) => p.kind === k && p.enabled);
              return <span key={k} className={`chip ${on ? "" : "opacity-40"}`}>{k.toLowerCase()}{on ? " ✓" : ""}</span>;
            })}
          </div>
        </div>
      </div>

      {isOwner && <AgentChat appId={app.id} initialIdea={app.idea} autoStart={app.status === "DRAFT"} />}
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string | number }) {
  return <div className="card"><p className="text-xs text-zinc-500">{label}</p><p className="text-xl font-semibold">{value}</p></div>;
}
