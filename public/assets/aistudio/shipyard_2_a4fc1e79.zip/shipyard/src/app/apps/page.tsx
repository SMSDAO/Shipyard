import Link from "next/link";
import { db } from "@/lib/db";
import { getUser } from "@/lib/auth";

export const dynamic = "force-dynamic";

export default async function MyApps() {
  const user = await getUser();
  if (!user) return <p className="card"><Link className="text-brand-600 underline" href="/login?next=/apps">Sign in</Link> to see your apps.</p>;

  const apps = await db.app.findMany({
    where: { OR: [{ ownerId: user.id }, { collaborators: { some: { userId: user.id } } }] },
    include: { wallet: true, token: true },
    orderBy: { updatedAt: "desc" },
  });

  return (
    <div className="space-y-4">
      <div className="card flex items-center justify-between">
        <div><p className="text-xs text-zinc-500">Credit balance</p><p className="text-2xl font-semibold">{user.credits}</p></div>
        <TopUp />
      </div>
      {apps.length === 0 ? (
        <div className="card text-center text-zinc-500">No apps yet. <Link className="text-brand-600 underline" href="/">Create your first one.</Link></div>
      ) : (
        <ul className="grid gap-3 sm:grid-cols-2">
          {apps.map((a) => (
            <li key={a.id}>
              <Link href={`/apps/${a.id}`} className="card block hover:border-brand-500">
                <div className="flex items-center justify-between"><h3 className="font-semibold">{a.name}</h3><span className="chip">{a.status}</span></div>
                <p className="mt-1 line-clamp-2 text-sm text-zinc-500">{a.idea}</p>
                <p className="mt-2 text-xs text-zinc-400">Wallet {a.wallet ? `${(Number(a.wallet.balanceWei) / 1e18).toFixed(3)} ETH` : "—"} · Updated {a.updatedAt.toLocaleDateString()}</p>
              </Link>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

import TopUp from "@/components/TopUp";
