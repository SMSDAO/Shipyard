import Link from "next/link";
import { db } from "@/lib/db";

export const dynamic = "force-dynamic";

export default async function Explore() {
  const apps = await db.app.findMany({
    where: { isPublic: true, status: "LIVE" },
    orderBy: { createdAt: "desc" },
    take: 48,
  });
  const trending = [...apps].sort((a, b) => b.opens - a.opens).slice(0, 3);

  return (
    <div className="space-y-6">
      <section>
        <h2 className="mb-2 font-semibold">Just shipped</h2>
        {apps.length === 0 ? <p className="card text-center text-zinc-500">Nothing live yet.</p> : <Grid apps={apps} />}
      </section>
      {trending.length > 0 && (<section><h2 className="mb-2 font-semibold">Trending</h2><Grid apps={trending} /></section>)}
    </div>
  );
}

function Grid({ apps }: { apps: Awaited<ReturnType<typeof db.app.findMany>> }) {
  return (
    <ul className="grid gap-3 sm:grid-cols-3">
      {apps.map((a) => (
        <li key={a.id}>
          <Link href={`/apps/${a.id}`} className="card block hover:border-brand-500">
            <h3 className="font-semibold">{a.name}</h3>
            <p className="line-clamp-2 text-sm text-zinc-500">{a.idea}</p>
            <p className="mt-2 text-xs text-zinc-400">{a.opens.toLocaleString()} opens</p>
          </Link>
        </li>
      ))}
    </ul>
  );
}
