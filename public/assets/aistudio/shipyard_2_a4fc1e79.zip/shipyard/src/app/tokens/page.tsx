import Link from "next/link";
import { db } from "@/lib/db";

export const dynamic = "force-dynamic";

export default async function Tokens() {
  const tokens = await db.token.findMany({ include: { app: true }, orderBy: { createdAt: "desc" }, take: 50 });
  if (tokens.length === 0) return <p className="card text-center text-zinc-500">No tokens launched yet.</p>;
  return (
    <ul className="space-y-2">
      {tokens.map((t) => (
        <li key={t.id}>
          <Link href={`/apps/${t.appId}`} className="card flex items-center justify-between hover:border-brand-500">
            <span><b>${t.symbol}</b> <span className="text-sm text-zinc-500">· {t.app.name}</span></span>
            <span className="text-sm text-zinc-500">{(Number(t.feesAccruedWei) / 1e18).toFixed(3)} ETH fees</span>
          </Link>
        </li>
      ))}
    </ul>
  );
}
