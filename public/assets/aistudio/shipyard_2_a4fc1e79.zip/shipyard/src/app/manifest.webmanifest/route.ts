export const GET = () =>
  Response.json({
    name: "Shipyard",
    short_name: "Shipyard",
    start_url: "/",
    display: "standalone",
    background_color: "#ecfdf5",
    theme_color: "#059669",
    icons: [{ src: "/icon.svg", sizes: "any", type: "image/svg+xml" }],
  });
