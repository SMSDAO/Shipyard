import Link from "next/link";

export default function NotFound() {
  return (
    <div className="card mx-auto max-w-md space-y-2 text-center">
      <h1 className="text-xl font-semibold">Nothing here</h1>
      <p className="text-sm opacity-70">That page doesn&apos;t exist, or you don&apos;t have access to it.</p>
      <Link href="/" className="btn">Back to Shipyard</Link>
    </div>
  );
}
