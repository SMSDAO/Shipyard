import Link from "next/link";
import { getUser } from "@/lib/auth";
import OrgAdmin from "@/components/OrgAdmin";

export const dynamic = "force-dynamic";

export default async function OrgPage() {
  const user = await getUser();
  if (!user) return <p className="card"><Link className="text-brand-600 underline" href="/login?next=/org">Sign in</Link> to manage your workspace.</p>;
  return <OrgAdmin />;
}
