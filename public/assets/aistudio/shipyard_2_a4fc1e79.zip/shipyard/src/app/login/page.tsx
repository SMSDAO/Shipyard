"use client";

import { Suspense, useEffect, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { usePrivy } from "@privy-io/react-auth";
import { toast } from "sonner";

const privyConfigured = !!process.env.NEXT_PUBLIC_PRIVY_APP_ID;

/** Only same-site relative paths are allowed as post-login targets (prevents open redirects). */
function safeNext(n: string | null) {
  return n && n.startsWith("/") && !n.startsWith("//") && !n.includes("\\") ? n : "/apps";
}

function PrivyLogin({ next }: { next: string }) {
  const router = useRouter();
  const { ready, authenticated, login, getAccessToken } = usePrivy();
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!ready || !authenticated || busy) return;
    setBusy(true);
    (async () => {
      const accessToken = await getAccessToken();
      const res = await fetch("/api/auth/privy", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ accessToken }) });
      if (!res.ok) throw new Error((await res.json()).error ?? "Sign-in failed");
      router.replace(next);
      router.refresh();
    })().catch((e) => { toast.error((e as Error).message); setBusy(false); });
  }, [ready, authenticated]); // eslint-disable-line react-hooks/exhaustive-deps

  return <button className="btn w-full" disabled={!ready || busy} onClick={login}>{busy ? "Signing in…" : "Continue"}</button>;
}

function DevLogin({ next }: { next: string }) {
  const router = useRouter();
  const [email, setEmail] = useState("");
  async function go(e: React.FormEvent) {
    e.preventDefault();
    const res = await fetch("/api/auth/dev-login", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ email }) });
    if (!res.ok) return toast.error((await res.json()).error ?? "Sign-in failed");
    router.replace(next);
    router.refresh();
  }
  return (
    <form onSubmit={go} className="space-y-2">
      <p className="text-xs text-amber-600">Dev login — Privy is not configured.</p>
      <input className="input" type="email" required value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com" />
      <button className="btn w-full">Sign in</button>
    </form>
  );
}

function Inner() {
  const next = safeNext(useSearchParams().get("next"));
  return (
    <div className="card mx-auto max-w-sm space-y-3">
      <h1 className="text-lg font-semibold">Sign in to Shipyard</h1>
      {privyConfigured ? <PrivyLogin next={next} /> : <DevLogin next={next} />}
    </div>
  );
}

export default function Login() {
  return <Suspense><Inner /></Suspense>;
}
