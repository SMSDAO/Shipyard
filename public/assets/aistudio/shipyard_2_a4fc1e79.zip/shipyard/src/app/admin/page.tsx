import { notFound } from "next/navigation";
import { db } from "@/lib/db";
import { getUser } from "@/lib/auth";
import { can } from "@/lib/rbac";

export const dynamic = "force-dynamic";

export default async function Admin() {
  const user = await getUser();
  if (!user || !can(user, "admin_panel")) notFound();

  const [users, apps, builds, failed, spent, flags, logs] = await Promise.all([
    db.user.count(), db.app.count(), db.buildJob.count(),
    db.buildJob.count({ where: { status: "FAILED" } }),
    db.creditTransaction.aggregate({ where: { type: "SPEND" }, _sum: { amount: true } }),
    db.featureFlag.findMany(),
    db.auditLog.findMany({ orderBy: { createdAt: "desc" }, take: 20 }),
  ]);
  const rate = builds ? Math.round(((builds - failed) / builds) * 100) : null;

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        {[["Users", users], ["Apps", apps], ["Build success", rate === null ? "—" : `${rate}%`], ["Credits spent", Math.abs(spent._sum.amount ?? 0)]].map(([l, v]) => (
          <div key={String(l)} className="card text-center"><p className="text-xs text-zinc-500">{l}</p><p className="text-xl font-semibold">{v}</p></div>
        ))}
      </div>
      <div className="card">
        <h2 className="mb-2 font-semibold">Feature flags</h2>
        <ul className="text-sm">{flags.map((f) => <li key={f.key}>{f.key}: {f.enabled ? "on" : "off"}</li>)}</ul>
      </div>
      <div className="card">
        <h2 className="mb-2 font-semibold">Audit log</h2>
        <ul className="space-y-1 font-mono text-xs text-zinc-500">
          {logs.map((l) => <li key={l.id}>{l.createdAt.toISOString()} · {l.action} {l.target ?? ""}</li>)}
        </ul>
      </div>
    </div>
  );
}
