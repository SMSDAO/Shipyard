"use client";

import { PrivyProvider } from "@privy-io/react-auth";

/** Wraps the app in Privy when NEXT_PUBLIC_PRIVY_APP_ID is set; otherwise renders children as-is (dev). */
export default function Providers({ children }: { children: React.ReactNode }) {
  const appId = process.env.NEXT_PUBLIC_PRIVY_APP_ID;
  if (!appId) return <>{children}</>;
  return (
    <PrivyProvider
      appId={appId}
      config={{
        loginMethods: ["email", "wallet", "twitter", "farcaster"],
        appearance: { theme: "light", accentColor: "#059669" },
        embeddedWallets: { ethereum: { createOnLogin: "users-without-wallets" } },
      }}
    >
      {children}
    </PrivyProvider>
  );
}
