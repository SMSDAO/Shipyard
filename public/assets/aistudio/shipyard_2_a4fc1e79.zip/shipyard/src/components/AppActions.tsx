"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { toast } from "sonner";

export default function AppActions({ appId, mode, disabled }: { appId: string; mode: "withdraw" | "claim"; disabled?: boolean }) {
  const router = useRouter();
  const [to, setTo] = useState("");
  const [eth, setEth] = useState("");
  const [busy, setBusy] = useState(false);

  async function run() {
    setBusy(true);
    try {
      const init =
        mode === "claim"
          ? { url: "/api/tokens/claim", body: { appId } }
          : { url: "/api/wallet/withdraw", body: { appId, toAddress: to, amountWei: BigInt(Math.round(Number(eth) * 1e9)).toString() + "000000000" } };
      const res = await fetch(init.url, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(init.body) });
      const d = await res.json();
      if (!res.ok) throw new Error(d.error ?? "Failed");
      toast.success(mode === "claim" ? "Fees claimed" : "Withdrawal submitted");
      router.refresh();
    } catch (e) {
      toast.error((e as Error).message);
    } finally {
      setBusy(false);
    }
  }

  if (mode === "claim") return <button className="btn" disabled={busy || disabled} onClick={run}>{busy ? "Claiming…" : "Claim fees"}</button>;
  return (
    <div className="flex flex-col gap-2 sm:flex-row">
      <input className="input" placeholder="0x… destination" value={to} onChange={(e) => setTo(e.target.value)} />
      <input className="input sm:w-28" placeholder="ETH" inputMode="decimal" value={eth} onChange={(e) => setEth(e.target.value)} />
      <button className="btn" disabled={busy || !to || !eth} onClick={run}>Withdraw</button>
    </div>
  );
}
