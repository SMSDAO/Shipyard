"use client";

import { useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import BuildTimeline from "./BuildTimeline";

interface Msg { id: string; role: "USER" | "ASSISTANT"; content: string }

export default function AgentChat({ appId, initialIdea, autoStart }: { appId: string; initialIdea: string; autoStart: boolean }) {
  const router = useRouter();
  const [messages, setMessages] = useState<Msg[]>([]);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const [step, setStep] = useState<string | null>(null);
  const started = useRef(false);

  async function load() {
    const res = await fetch(`/api/agent?appId=${appId}`);
    if (!res.ok) return;
    const d = await res.json();
    setMessages(d.messages);
    setStep(d.status === "LIVE" ? null : d.step);
  }

  async function send(text: string) {
    if (!text.trim() || busy) return;
    setBusy(true);
    setMessages((m) => [...m, { id: `tmp-${Date.now()}`, role: "USER", content: text }]);
    setInput("");
    // Poll progress while the (long-running) agent turn is in flight.
    const poll = setInterval(load, 2500);
    try {
      const res = await fetch("/api/agent", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ appId, message: text }) });
      const d = await res.json();
      if (!res.ok) throw new Error(d.error ?? "Agent error");
      await load();
      router.refresh();
    } catch (e) {
      toast.error((e as Error).message);
    } finally {
      clearInterval(poll);
      setBusy(false);
    }
  }

  useEffect(() => {
    load();
    if (autoStart && !started.current) { started.current = true; send(initialIdea); }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <aside className="card flex h-[70vh] flex-col">
      <h2 className="mb-2 font-semibold">Build agent</h2>
      <div className="flex-1 space-y-2 overflow-y-auto text-sm">
        {messages.length === 0 && <p className="text-zinc-500">Tell the agent what to build or change.</p>}
        {messages.map((m) => (
          <div key={m.id} className={`whitespace-pre-wrap rounded-xl px-3 py-2 ${m.role === "USER" ? "ml-8 bg-brand-500/15" : "mr-8 glass"}`}>{m.content}</div>
        ))}
        {busy && (<div className="space-y-1"><BuildTimeline step={step} /><p className="text-xs opacity-70">{step ?? "Working…"}</p></div>)}
      </div>
      <form className="mt-2 flex gap-2" onSubmit={(e) => { e.preventDefault(); send(input); }}>
        <input className="input" value={input} onChange={(e) => setInput(e.target.value)} placeholder='Answer, iterate, or say "Surprise me"' />
        <button className="btn" disabled={busy}>Send</button>
      </form>
    </aside>
  );
}
