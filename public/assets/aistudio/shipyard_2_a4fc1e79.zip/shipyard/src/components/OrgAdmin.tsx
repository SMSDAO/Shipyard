"use client";

import { useCallback, useEffect, useState } from "react";
import { toast } from "sonner";

type Role = "OWNER" | "ADMIN" | "BUILDER" | "VIEWER";
interface Org { id: string; name: string; slug: string; role: Role }
interface Member { userId: string; role: Role; handle: string | null; email: string | null }
interface Hook { id: string; url: string; events: string[]; enabled: boolean }
interface Key { id: string; name: string; prefix: string; readOnly: boolean; lastUsedAt: string | null }

const EVENTS = ["*", "app.live", "app.failed", "wallet.withdrawal", "fees.claimed", "member.added", "member.removed"];

async function api<T>(url: string, init?: RequestInit): Promise<T> {
  const res = await fetch(url, { ...init, headers: { "Content-Type": "application/json" } });
  const d = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(d.error ?? "Request failed");
  return d as T;
}

export default function OrgAdmin() {
  const [orgs, setOrgs] = useState<Org[]>([]);
  const [orgId, setOrgId] = useState<string>("");
  const [members, setMembers] = useState<Member[]>([]);
  const [hooks, setHooks] = useState<Hook[]>([]);
  const [keys, setKeys] = useState<Key[]>([]);
  const [secret, setSecret] = useState<{ label: string; value: string } | null>(null);
  const org = orgs.find((o) => o.id === orgId);
  const canManage = org?.role === "OWNER" || org?.role === "ADMIN";

  const fail = (e: unknown) => toast.error((e as Error).message);

  const loadOrgs = useCallback(async () => {
    const { orgs } = await api<{ orgs: Org[] }>("/api/orgs");
    setOrgs(orgs);
    setOrgId((cur) => cur || orgs[0]?.id || "");
  }, []);
  const loadKeys = useCallback(() => api<{ keys: Key[] }>("/api/api-keys").then((d) => setKeys(d.keys)), []);

  useEffect(() => { loadOrgs().catch(fail); loadKeys().catch(fail); }, [loadOrgs, loadKeys]);

  const loadOrg = useCallback(async () => {
    if (!orgId) return;
    setMembers((await api<{ members: Member[] }>(`/api/orgs/${orgId}/members`)).members);
    if (canManage) setHooks((await api<{ endpoints: Hook[] }>(`/api/orgs/${orgId}/webhooks`)).endpoints);
    else setHooks([]);
  }, [orgId, canManage]);
  useEffect(() => { loadOrg().catch(fail); }, [loadOrg]);

  async function createOrg(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const f = new FormData(e.currentTarget);
    try {
      await api("/api/orgs", { method: "POST", body: JSON.stringify({ name: f.get("name"), slug: f.get("slug") }) });
      e.currentTarget.reset();
      await loadOrgs();
    } catch (err) { fail(err); }
  }

  async function invite(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const f = new FormData(e.currentTarget);
    try {
      const d = await api<{ emailed: boolean; inviteUrl?: string }>(`/api/orgs/${orgId}/invitations`, { method: "POST", body: JSON.stringify({ email: f.get("email"), role: f.get("role") }) });
      e.currentTarget.reset();
      if (d.inviteUrl) setSecret({ label: "Invite link (email not configured — share it manually)", value: d.inviteUrl });
      else toast.success("Invitation sent");
    } catch (err) { fail(err); }
  }

  async function addHook(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const f = new FormData(e.currentTarget);
    try {
      const d = await api<{ secret: string }>(`/api/orgs/${orgId}/webhooks`, { method: "POST", body: JSON.stringify({ url: f.get("url"), events: f.getAll("events") }) });
      setSecret({ label: "Signing secret (shown once)", value: d.secret });
      e.currentTarget.reset();
      await loadOrg();
    } catch (err) { fail(err); }
  }

  async function addKey(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const f = new FormData(e.currentTarget);
    try {
      const d = await api<{ key: string }>("/api/api-keys", { method: "POST", body: JSON.stringify({ name: f.get("name"), readOnly: f.get("readOnly") === "on" }) });
      setSecret({ label: "API key (shown once)", value: d.key });
      e.currentTarget.reset();
      await loadKeys();
    } catch (err) { fail(err); }
  }

  const act = (fn: () => Promise<unknown>) => fn().then(() => loadOrg()).catch(fail);

  return (
    <div className="space-y-4">
      {secret && (
        <div className="card border-amber-400">
          <p className="text-sm font-medium">{secret.label}</p>
          <code className="block break-all rounded bg-zinc-100 p-2 text-xs dark:bg-zinc-800">{secret.value}</code>
          <button className="btn-ghost mt-2" onClick={() => { navigator.clipboard.writeText(secret.value); setSecret(null); }}>Copy & dismiss</button>
        </div>
      )}

      <div className="card flex flex-wrap items-center gap-2">
        <select className="input w-auto" value={orgId} onChange={(e) => setOrgId(e.target.value)}>
          {orgs.length === 0 && <option value="">No workspaces yet</option>}
          {orgs.map((o) => <option key={o.id} value={o.id}>{o.name} ({o.role.toLowerCase()})</option>)}
        </select>
        <form onSubmit={createOrg} className="ml-auto flex gap-2">
          <input className="input w-36" name="name" placeholder="New workspace" required minLength={2} />
          <input className="input w-28" name="slug" placeholder="slug" required pattern="[a-z0-9][a-z0-9\-]{1,38}[a-z0-9]" />
          <button className="btn">Create</button>
        </form>
      </div>

      {org && (
        <section className="card space-y-2">
          <h2 className="font-semibold">Members</h2>
          <ul className="divide-y divide-zinc-200 text-sm dark:divide-zinc-800">
            {members.map((m) => (
              <li key={m.userId} className="flex items-center gap-2 py-2">
                <span className="flex-1 truncate">{m.email ?? m.handle ?? m.userId}</span>
                <select className="input w-auto" disabled={!canManage} value={m.role}
                  onChange={(e) => act(() => api(`/api/orgs/${orgId}/members/${m.userId}`, { method: "PATCH", body: JSON.stringify({ role: e.target.value }) }))}>
                  {(["OWNER", "ADMIN", "BUILDER", "VIEWER"] as Role[]).map((r) => <option key={r}>{r}</option>)}
                </select>
                {canManage && <button className="btn-ghost" onClick={() => confirm("Remove this member?") && act(() => api(`/api/orgs/${orgId}/members/${m.userId}`, { method: "DELETE" }))}>Remove</button>}
              </li>
            ))}
          </ul>
          {canManage && (
            <form onSubmit={invite} className="flex flex-wrap gap-2">
              <input className="input flex-1" name="email" type="email" placeholder="teammate@company.com" required />
              <select className="input w-auto" name="role" defaultValue="BUILDER">{["ADMIN", "BUILDER", "VIEWER"].map((r) => <option key={r}>{r}</option>)}</select>
              <button className="btn">Invite</button>
            </form>
          )}
        </section>
      )}

      {org && canManage && (
        <section className="card space-y-2">
          <div className="flex items-center justify-between">
            <h2 className="font-semibold">Webhooks</h2>
            <a className="btn-ghost" href={`/api/orgs/${orgId}/audit?format=csv&limit=10000`}>Export audit log (CSV)</a>
          </div>
          <ul className="space-y-1 text-sm">
            {hooks.map((h) => (
              <li key={h.id} className="flex items-center gap-2">
                <span className="flex-1 truncate">{h.url} <span className="text-xs text-zinc-500">({h.events.join(", ")})</span></span>
                <button className="btn-ghost" onClick={() => act(() => api(`/api/orgs/${orgId}/webhooks/${h.id}`, { method: "DELETE" }))}>Delete</button>
              </li>
            ))}
            {hooks.length === 0 && <li className="text-zinc-500">No endpoints.</li>}
          </ul>
          <form onSubmit={addHook} className="space-y-2">
            <input className="input" name="url" type="url" placeholder="https://example.com/hooks/shipyard" required />
            <div className="flex flex-wrap gap-3 text-xs">
              {EVENTS.map((ev) => <label key={ev} className="flex items-center gap-1"><input type="checkbox" name="events" value={ev} defaultChecked={ev === "app.live"} />{ev}</label>)}
            </div>
            <button className="btn">Add endpoint</button>
          </form>
        </section>
      )}

      <section className="card space-y-2">
        <h2 className="font-semibold">Your API keys</h2>
        <ul className="space-y-1 text-sm">
          {keys.map((k) => (
            <li key={k.id} className="flex items-center gap-2">
              <span className="flex-1">{k.name} <code className="text-xs text-zinc-500">{k.prefix}…</code> {k.readOnly && <span className="chip">read-only</span>}</span>
              <button className="btn-ghost" onClick={() => api(`/api/api-keys/${k.id}`, { method: "DELETE" }).then(loadKeys).catch(fail)}>Revoke</button>
            </li>
          ))}
          {keys.length === 0 && <li className="text-zinc-500">No keys.</li>}
        </ul>
        <form onSubmit={addKey} className="flex flex-wrap items-center gap-2">
          <input className="input flex-1" name="name" placeholder="Key name (e.g. CI)" required maxLength={60} />
          <label className="flex items-center gap-1 text-xs"><input type="checkbox" name="readOnly" /> read-only</label>
          <button className="btn">Create key</button>
        </form>
      </section>
    </div>
  );
}
