"use client";

import { useRouter } from "next/navigation";
import { toast } from "sonner";

export default function TopUp() {
  const router = useRouter();
  async function buy(pack: string) {
    const res = await fetch("/api/credits", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ pack }) });
    const data = await res.json();
    if (!res.ok) return toast.error(data.error ?? "Top-up failed");
    if (data.checkoutUrl) window.location.href = data.checkoutUrl;
    else { toast.success(`Added ${data.granted} credits`); router.refresh(); }
  }
  return (
    <div className="flex gap-2">
      {["100", "500", "2000"].map((p) => (
        <button key={p} className="btn-ghost" onClick={() => buy(p)}>+{p}</button>
      ))}
    </div>
  );
}
