import { PrismaClient } from "@prisma/client";

const db = new PrismaClient();

async function main() {
  const admin = await db.user.upsert({
    where: { email: "admin@shipyard.local" },
    update: {},
    create: { email: "admin@shipyard.local", handle: "admin", platformRole: "SUPER_ADMIN", credits: 10_000 },
  });
  const alice = await db.user.upsert({
    where: { email: "alice@shipyard.local" },
    update: {},
    create: { email: "alice@shipyard.local", handle: "alice", credits: 500 },
  });
  const bob = await db.user.upsert({
    where: { email: "bob@shipyard.local" },
    update: {},
    create: { email: "bob@shipyard.local", handle: "bob", credits: 200 },
  });

  const org = await db.organization.upsert({
    where: { slug: "demo-studio" },
    update: {},
    create: { name: "Demo Studio", slug: "demo-studio" },
  });
  await db.membership.upsert({
    where: { userId_orgId: { userId: alice.id, orgId: org.id } },
    update: {},
    create: { userId: alice.id, orgId: org.id, role: "OWNER" },
  });
  await db.membership.upsert({
    where: { userId_orgId: { userId: bob.id, orgId: org.id } },
    update: {},
    create: { userId: bob.id, orgId: org.id, role: "BUILDER" },
  });

  const demos = [
    { name: "Pixel Arcade", slug: "pixel-arcade", idea: "Retro arcade games with onchain high scores and weekly prizes.", opens: 1840, uniqueUsers: 612 },
    { name: "TipJar", slug: "tipjar", idea: "A tipping bot that lets fans send micro-tips to creators in chat.", opens: 920, uniqueUsers: 301 },
    { name: "Memeforge", slug: "memeforge", idea: "Generate and mint memes from a single prompt with creator royalties.", opens: 2210, uniqueUsers: 877 },
  ];

  for (const d of demos) {
    const app = await db.app.upsert({
      where: { slug: d.slug },
      update: {},
      create: {
        ...d,
        status: "LIVE",
        liveUrl: `https://${d.slug}.example.app`,
        repoUrl: `https://github.com/shipyard-demo/${d.slug}`,
        ownerId: alice.id,
        orgId: org.id,
      },
    });
    await db.appWallet.upsert({
      where: { appId: app.id },
      update: {},
      create: {
        appId: app.id,
        address: "0x" + app.id.replace(/[^a-f0-9]/gi, "0").padEnd(40, "0").slice(0, 40),
        providerRef: `mock-${app.id}`,
        balanceWei: "250000000000000000",
      },
    });
    await db.token.upsert({
      where: { appId: app.id },
      update: {},
      create: {
        appId: app.id,
        symbol: d.name.replace(/[^A-Za-z]/g, "").slice(0, 5).toUpperCase(),
        name: `${d.name} Token`,
        feesAccruedWei: "400000000000000000",
      },
    });
    for (const kind of ["WEB", "FARCASTER"] as const) {
      await db.platformIntegration.upsert({
        where: { appId_kind: { appId: app.id, kind } },
        update: {},
        create: { appId: app.id, kind, enabled: true },
      });
    }
  }

  for (const key of ["token_launch", "x_free_build", "world_app"]) {
    await db.featureFlag.upsert({ where: { key }, update: {}, create: { key, enabled: true } });
  }
  await db.auditLog.create({ data: { actorId: admin.id, action: "seed.completed" } });
  console.log("Seeded.");
}

main().finally(() => db.$disconnect());
