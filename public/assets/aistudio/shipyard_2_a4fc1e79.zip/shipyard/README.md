# Shipyard

Describe an idea → a team of AI agents plans, designs, builds, reviews and deploys an onchain miniapp. Next.js 15 · Prisma/Postgres · Claude tool-calling · glass UI.

> **Status:** feature-complete source, **not yet compiled or run end-to-end** (the authoring environment had no npm access). 53 unit tests over the pure logic pass under Bun. Run the checklist below before real users or real funds.

## Quick start

```bash
cp .env.example .env          # set DATABASE_URL, AUTH_SECRET, ENCRYPTION_KEY at minimum
npm install
npx prisma migrate dev --name init   # commit prisma/migrations/
npm run db:seed
npm run dev                   # http://localhost:3000
```

Docker: `docker compose up --build`. Seed logins (dev login, local only): `admin@shipyard.local` (super admin), `alice@shipyard.local` (owner), `bob@shipyard.local` (builder).

## Verify before launch

```bash
npm run typecheck && npm test && npm run build
```

Expect to fix a few type errors on first compile. Then walk through: sign in → create app → answer planner questions → watch the agent timeline → open live app → invite a teammate → create webhook → rotate an API key.

## Architecture

| Area | Where | Notes |
|---|---|---|
| Agents | `src/lib/agent/` | **Planner** (model: asks questions, sets plan) → **Designer** → **Coder** → **Reviewer** (gate) → **Deployer**. Each role has an enforced tool allow-list (`roles.ts`). Reviewer blocks secrets, `eval`, `child_process`, `tx.origin`, unsafe paths before GitHub/Vercel; credits are refunded on rejection. Offline (no `ANTHROPIC_API_KEY`) the Planner is skipped and defaults apply. |
| Auth | `lib/auth.ts`, `api/auth/privy` | Privy token → signed session cookie, or `Bearer sk_…` API keys (hashed at rest, read-only scope, can't mint keys). Dev login is blocked in production. |
| RBAC | `lib/rbac.ts`, `lib/org.ts` | Super admin / owner / admin / builder / viewer; only owners grant owner; last owner protected; non-members get 404. |
| Orgs | `api/orgs/**`, `/org` page | Members, single-use 7-day invites, org-scoped audit log with CSV export. |
| Webhooks | `lib/webhooks*.ts` | HMAC-signed, SSRF-guarded (public https only, no redirects), retried with backoff by cron. |
| Money | `api/wallet`, `api/tokens`, `lib/credits.ts` | Optimistic-locked balance updates, atomic credit spend, idempotent Stripe webhook. |
| Platforms | `api/apps/[id]/platforms` | Farcaster manifest, Telegram bot (webhook + secret), World app id, Base, Celo. Secrets AES-256-GCM encrypted. |
| Ops | `api/health`, `lib/http.ts` | Structured JSON logs, request ids, Upstash rate limits (in-memory fallback), cron. |
| UI | `src/app`, `globals.css` | Glass design system, aurora backdrop (reduced-motion safe), automatic dark mode, loading/empty/error states. |
| SDK / API | `sdk/`, `docs/openapi.yaml` | Typed client incl. `verifyWebhook`; OpenAPI 3 for every route. |
| Data | `prisma/`, `db/schema.sql` | 21 models. Prisma is the migration source; the SQL file is a reference. |
| Brand | `brand/` | Logos, OG image, guide. |

## Deploy (Vercel)

1. Create Postgres (Neon/Supabase) → `DATABASE_URL`. Run `npx prisma migrate deploy` against it (CI/CD step, not at build time).
2. Import the repo, add env vars from `.env.example` (`AUTH_SECRET`, `ENCRYPTION_KEY`, `CRON_SECRET`, Privy, Stripe, Upstash are the important ones).
3. Stripe webhook → `/api/stripe/webhook` for `checkout.session.completed`.
4. Cron is configured in `vercel.json` (webhook retries every 5 min).

## What is still mocked

These need real credentials/integration work; each degrades to a mock when unset:

- **Wallets / token launch** (`lib/services/providers.ts`): CDP and Clanker calls are marked placeholders returning mock addresses. **Withdrawals record intent and update the DB balance but do not sign or broadcast a transaction.** Do not enable with real funds until wired to the wallet provider.
- **World / Celo / Base** have toggles and config only; no store-specific manifest or verification flow beyond World app id.
- **Build progress** uses polling, not realtime.
- **Code generation quality** depends on the model; the Reviewer is static analysis, not a security audit.
- Webhook SSRF guard resolves DNS separately from the request; for strict environments run delivery behind an egress proxy that blocks private ranges.

See `docs/RUNBOOK.md` for operations and `docs/SECURITY.md` for the threat model.
