# Runbook

## Health
- `GET /api/health` → `{status:"ok"}` or 503 `{status:"degraded"}` (DB unreachable). Point uptime monitors here.
- Logs are one JSON object per line (`level`, `msg`, `ts`, `requestId`). Every API response carries `x-request-id`; users can quote it in support requests.

## Secrets
| Secret | Rotate by |
|---|---|
| `AUTH_SECRET` | Change it; all sessions are invalidated (users sign in again). |
| `ENCRYPTION_KEY` | Decrypt every `WebhookEndpoint.secretEnc` and `PlatformIntegration.config.*Enc` with the old key, re-encrypt with the new one, then switch. Ciphertext is versioned `v1:`. Changing the key without migrating makes those secrets unreadable (webhook endpoints must be recreated; Telegram bots reconnected). |
| `CRON_SECRET` | Change in Vercel; cron picks it up on next deploy. |
| User API key | User revokes in Team page; keys are stored hashed so leaked DB contents don't expose them. |

## Common incidents
- **Builds stuck in GENERATING/DEPLOYING:** the request timed out (300 s limit). Check `BuildJob.error` / `step`; the user can resend a message to retry. Credits already spent on a failed deploy are not refunded automatically (only reviewer rejections are).
- **Webhooks not arriving:** `WebhookDelivery` rows with `deliveredAt IS NULL` show `lastStatus`/`lastError`. Retries happen via `/api/cron/webhooks`; confirm the cron is running and `CRON_SECRET` matches. After 6 attempts `nextAttemptAt` is null (dead).
- **429s:** limits are per user/IP (see `api/*` routes). Without Upstash env vars limits are per instance only.
- **Stripe credits missing:** check the webhook delivery in Stripe; handler is idempotent by checkout session id, so replaying is safe.

## Backups & data
- Enable point-in-time recovery on Postgres. `AuditLog` is append-only by convention (no code path updates/deletes it); restrict DB roles accordingly.
- Wallet private keys are never stored; only provider references.

## Release checklist
1. `npm run typecheck && npm test && npm run build` green in CI.
2. `prisma migrate deploy` on a staging DB first.
3. Smoke test: sign in, create app, build completes, webhook test endpoint receives `app.live`.
