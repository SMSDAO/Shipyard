# Security model

## Controls implemented
- **AuthN:** Privy JWT verified (ES256, issuer, audience) → HttpOnly, SameSite=Lax, Secure session cookie. API keys: 256-bit random, SHA-256 hashed at rest, optional expiry, read-only scope, revocable, cannot create other keys.
- **AuthZ:** central permission matrix (`lib/rbac.ts`) checked in every route; org routes 404 for non-members; owner role changes restricted; last owner protected.
- **CSRF:** middleware rejects cross-origin mutating requests on cookie auth (Origin must match Host); Bearer-key calls and signed webhooks are exempt.
- **Input:** zod validation on all bodies, prompt sanitization, length caps, bigint-safe money math.
- **Secrets at rest:** AES-256-GCM (`lib/crypto.ts`) for webhook signing secrets and bot tokens; never returned by any API.
- **SSRF:** webhook URLs must be https and resolve to public IPs; redirects are not followed; per-request timeout.
- **Generated code:** Reviewer gate (secrets, eval, child_process, tx.origin, unsafe paths, size/file limits) before any push; GitHub writer re-validates paths.
- **Money:** credit spend and wallet/fee updates use compare-and-set inside transactions; Stripe webhook signature-verified with timestamp tolerance and idempotent.
- **Audit:** privileged actions recorded with actor, org and target; CSV export neutralizes spreadsheet formulas.
- **Headers:** CSP, HSTS, nosniff, Referrer-Policy, Permissions-Policy, no `X-Powered-By`.

## Known gaps / assumptions
- CSP allows `'unsafe-inline'`/`'unsafe-eval'` scripts (Next.js/Privy requirement); move to nonces for a stricter policy.
- Rate limiting fails open if Redis is unreachable (availability over strictness).
- The DNS check for webhooks is not pinned to the connection (DNS rebinding); use an egress proxy in high-assurance setups.
- Withdrawals/token launches are not wired to a signing provider (see README). No on-chain operation has been executed or tested.
- Row-level security is enforced in application code, not Postgres RLS policies.
- No third-party penetration test or formal audit has been performed. Get one before handling real funds.

## Reporting
Send vulnerability reports privately to the maintainers; do not open public issues.
