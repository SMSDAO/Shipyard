import type { Config } from "tailwindcss";

const config: Config = {
  // Follows the OS setting; the glass tokens in globals.css switch with prefers-color-scheme.
  darkMode: "media",
  content: ["./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        brand: { 50: "#ecfdf5", 400: "#34d399", 500: "#10b981", 600: "#059669", 700: "#047857" },
      },
      fontFamily: { sans: ["Inter", "ui-sans-serif", "system-ui", "sans-serif"] },
    },
  },
  plugins: [],
};

export default config;
