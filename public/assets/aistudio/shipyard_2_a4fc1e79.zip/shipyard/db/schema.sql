-- Shipyard PostgreSQL reference schema (mirrors prisma/schema.prisma).
-- The source of truth for migrations is Prisma: run `npx prisma migrate dev --name init`.
-- Use this file for DBA review, ERD tooling, or bootstrapping a non-Prisma consumer.

CREATE TYPE "PlatformRole"  AS ENUM ('SUPER_ADMIN', 'USER');
CREATE TYPE "OrgRole"       AS ENUM ('OWNER', 'ADMIN', 'BUILDER', 'VIEWER');
CREATE TYPE "AppStatus"     AS ENUM ('DRAFT', 'QUEUED', 'CLARIFYING', 'GENERATING', 'DEPLOYING', 'LIVE', 'FAILED');
CREATE TYPE "BuildStatus"   AS ENUM ('QUEUED', 'CLARIFYING', 'GENERATING', 'DEPLOYING', 'LIVE', 'FAILED');
CREATE TYPE "CreditTxType"  AS ENUM ('PURCHASE', 'SPEND', 'GRANT', 'ADJUSTMENT');
CREATE TYPE "PlatformKind"  AS ENUM ('WEB', 'FARCASTER', 'TELEGRAM', 'WORLD', 'CELO', 'BASE');
CREATE TYPE "MessageRole"   AS ENUM ('USER', 'ASSISTANT', 'TOOL', 'SYSTEM');

CREATE TABLE "User" (
  id            TEXT PRIMARY KEY,
  email         TEXT UNIQUE,
  handle        TEXT UNIQUE,
  "walletAddr"  TEXT UNIQUE,
  "privyId"     TEXT UNIQUE,
  "xHandle"     TEXT,
  "platformRole" "PlatformRole" NOT NULL DEFAULT 'USER',
  credits       INTEGER NOT NULL DEFAULT 0 CHECK (credits >= 0),
  "createdAt"   TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE "Organization" (
  id          TEXT PRIMARY KEY,
  name        TEXT NOT NULL,
  slug        TEXT NOT NULL UNIQUE,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE "Membership" (
  id       TEXT PRIMARY KEY,
  "userId" TEXT NOT NULL REFERENCES "User"(id) ON DELETE CASCADE,
  "orgId"  TEXT NOT NULL REFERENCES "Organization"(id) ON DELETE CASCADE,
  role     "OrgRole" NOT NULL DEFAULT 'VIEWER',
  UNIQUE ("userId", "orgId")
);

CREATE TABLE "App" (
  id             TEXT PRIMARY KEY,
  name           VARCHAR(30) NOT NULL,
  slug           TEXT NOT NULL UNIQUE,
  idea           TEXT NOT NULL,
  status         "AppStatus" NOT NULL DEFAULT 'DRAFT',
  "isPublic"     BOOLEAN NOT NULL DEFAULT TRUE,
  "liveUrl"      TEXT,
  "repoUrl"      TEXT,
  "vercelId"     TEXT,
  "logoUrl"      TEXT,
  opens          INTEGER NOT NULL DEFAULT 0,
  "uniqueUsers"  INTEGER NOT NULL DEFAULT 0,
  "revenueCents" INTEGER NOT NULL DEFAULT 0,
  "ownerId"      TEXT NOT NULL REFERENCES "User"(id),
  "orgId"        TEXT REFERENCES "Organization"(id),
  "createdAt"    TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt"    TIMESTAMP(3) NOT NULL
);
CREATE INDEX "App_isPublic_status_createdAt_idx" ON "App" ("isPublic", status, "createdAt");

CREATE TABLE "AppCollaborator" (
  id       TEXT PRIMARY KEY,
  "appId"  TEXT NOT NULL REFERENCES "App"(id) ON DELETE CASCADE,
  "userId" TEXT NOT NULL REFERENCES "User"(id) ON DELETE CASCADE,
  role     "OrgRole" NOT NULL DEFAULT 'BUILDER',
  UNIQUE ("appId", "userId")
);

CREATE TABLE "AppVersion" (
  id          TEXT PRIMARY KEY,
  "appId"     TEXT NOT NULL REFERENCES "App"(id) ON DELETE CASCADE,
  number      INTEGER NOT NULL,
  summary     TEXT NOT NULL,
  "commitSha" TEXT,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE ("appId", number)
);

CREATE TABLE "AppWallet" (
  id            TEXT PRIMARY KEY,
  "appId"       TEXT NOT NULL UNIQUE REFERENCES "App"(id) ON DELETE CASCADE,
  address       TEXT NOT NULL UNIQUE,
  "providerRef" TEXT NOT NULL,            -- CDP/Privy wallet id; private keys are never stored
  "balanceWei"  TEXT NOT NULL DEFAULT '0',
  "createdAt"   TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE "Withdrawal" (
  id          TEXT PRIMARY KEY,
  "walletId"  TEXT NOT NULL REFERENCES "AppWallet"(id) ON DELETE CASCADE,
  "toAddress" TEXT NOT NULL,
  "amountWei" TEXT NOT NULL,
  "txHash"    TEXT,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE "Token" (
  id                TEXT PRIMARY KEY,
  "appId"           TEXT NOT NULL UNIQUE REFERENCES "App"(id) ON DELETE CASCADE,
  symbol            TEXT NOT NULL,
  name              TEXT NOT NULL,
  contract          TEXT,
  "creatorShareBps" INTEGER NOT NULL DEFAULT 6000,
  "feesAccruedWei"  TEXT NOT NULL DEFAULT '0',
  "feesClaimedWei"  TEXT NOT NULL DEFAULT '0',
  "createdAt"       TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE "FeeClaim" (
  id          TEXT PRIMARY KEY,
  "tokenId"   TEXT NOT NULL REFERENCES "Token"(id) ON DELETE CASCADE,
  "amountWei" TEXT NOT NULL,
  "txHash"    TEXT,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE "CreditTransaction" (
  id          TEXT PRIMARY KEY,
  "userId"    TEXT NOT NULL REFERENCES "User"(id) ON DELETE CASCADE,
  type        "CreditTxType" NOT NULL,
  amount      INTEGER NOT NULL,
  reason      TEXT NOT NULL,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX "CreditTransaction_userId_createdAt_idx" ON "CreditTransaction" ("userId", "createdAt");

CREATE TABLE "BuildJob" (
  id          TEXT PRIMARY KEY,
  "appId"     TEXT NOT NULL REFERENCES "App"(id) ON DELETE CASCADE,
  status      "BuildStatus" NOT NULL DEFAULT 'QUEUED',
  step        TEXT NOT NULL DEFAULT 'queued',
  error       TEXT,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL
);

CREATE TABLE "Conversation" (
  id      TEXT PRIMARY KEY,
  "appId" TEXT NOT NULL UNIQUE REFERENCES "App"(id) ON DELETE CASCADE
);

CREATE TABLE "Message" (
  id               TEXT PRIMARY KEY,
  "conversationId" TEXT NOT NULL REFERENCES "Conversation"(id) ON DELETE CASCADE,
  role             "MessageRole" NOT NULL,
  content          TEXT NOT NULL,
  "toolName"       TEXT,
  "createdAt"      TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX "Message_conversationId_createdAt_idx" ON "Message" ("conversationId", "createdAt");

CREATE TABLE "PlatformIntegration" (
  id      TEXT PRIMARY KEY,
  "appId" TEXT NOT NULL REFERENCES "App"(id) ON DELETE CASCADE,
  kind    "PlatformKind" NOT NULL,
  enabled BOOLEAN NOT NULL DEFAULT FALSE,
  config  JSONB,
  UNIQUE ("appId", kind)
);

CREATE TABLE "FeatureFlag" (
  key     TEXT PRIMARY KEY,
  enabled BOOLEAN NOT NULL DEFAULT FALSE
);

CREATE TABLE "AuditLog" (
  id          TEXT PRIMARY KEY,
  "actorId"   TEXT REFERENCES "User"(id),
  "orgId"     TEXT,
  action      TEXT NOT NULL,
  target      TEXT,
  meta        JSONB,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX "AuditLog_createdAt_idx" ON "AuditLog" ("createdAt");
CREATE INDEX "AuditLog_orgId_createdAt_idx" ON "AuditLog" ("orgId", "createdAt");

CREATE TABLE "ApiKey" (
  id           TEXT PRIMARY KEY,
  "userId"     TEXT NOT NULL REFERENCES "User"(id) ON DELETE CASCADE,
  "orgId"      TEXT REFERENCES "Organization"(id) ON DELETE CASCADE,
  name         TEXT NOT NULL,
  prefix       TEXT NOT NULL,
  hash         TEXT NOT NULL UNIQUE,          -- SHA-256 of key; plaintext never stored
  "readOnly"   BOOLEAN NOT NULL DEFAULT FALSE,
  "lastUsedAt" TIMESTAMP(3),
  "expiresAt"  TIMESTAMP(3),
  "revokedAt"  TIMESTAMP(3),
  "createdAt"  TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX "ApiKey_userId_idx" ON "ApiKey" ("userId");

CREATE TABLE "Invitation" (
  id            TEXT PRIMARY KEY,
  "orgId"       TEXT NOT NULL REFERENCES "Organization"(id) ON DELETE CASCADE,
  email         TEXT NOT NULL,
  role          "OrgRole" NOT NULL DEFAULT 'VIEWER',
  "tokenHash"   TEXT NOT NULL UNIQUE,
  "invitedById" TEXT NOT NULL REFERENCES "User"(id),
  "expiresAt"   TIMESTAMP(3) NOT NULL,
  "acceptedAt"  TIMESTAMP(3),
  "createdAt"   TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX "Invitation_orgId_idx" ON "Invitation" ("orgId");

CREATE TABLE "WebhookEndpoint" (
  id          TEXT PRIMARY KEY,
  "orgId"     TEXT NOT NULL REFERENCES "Organization"(id) ON DELETE CASCADE,
  url         TEXT NOT NULL,
  "secretEnc" TEXT NOT NULL,                  -- AES-256-GCM ciphertext
  events      TEXT[] NOT NULL,
  enabled     BOOLEAN NOT NULL DEFAULT TRUE,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX "WebhookEndpoint_orgId_idx" ON "WebhookEndpoint" ("orgId");

CREATE TABLE "WebhookDelivery" (
  id              TEXT PRIMARY KEY,
  "endpointId"    TEXT NOT NULL REFERENCES "WebhookEndpoint"(id) ON DELETE CASCADE,
  event           TEXT NOT NULL,
  payload         JSONB NOT NULL,
  attempts        INTEGER NOT NULL DEFAULT 0,
  "lastStatus"    INTEGER,
  "lastError"     TEXT,
  "nextAttemptAt" TIMESTAMP(3),
  "deliveredAt"   TIMESTAMP(3),
  "createdAt"     TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX "WebhookDelivery_deliveredAt_nextAttemptAt_idx" ON "WebhookDelivery" ("deliveredAt", "nextAttemptAt");
